export class Registration {
    className:string='';
    place_name:string='';
    childId:string | undefined;
    aadharNO:string='';
    Admission:string='';
    bank_name:string='';
    ac_no:string='';
    ifsc_code:string='';
    fullNameofstudent:string='';
    Sex:string='';
    Male:string='';
    dateOfbirth:string='';
    Age:string='';
    placeof:string='';
    Nationality:string='';
    MotherTongue:string='';
    sche_cast:string='';
    Religion:string='';
    cast:string='';
    FatherName:string='';
    motherName:string='';
    PostalAddress:string='';
    mobilNo:string='';
    WhatsAppno:string='';
    emailAddress:string='';
    guardianName:string='';
    Relationship:string='';
    PostalAddressfamily:string='';
    bus_status:string='';
    bus_place:string='';
    year:string='';
    file:string='';
    sssm_id:string='';
    busNumber:string='';
    bus_number:string='';
    
}
