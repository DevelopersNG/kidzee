export class Fees {
    class_name:string='';
    child_id:string='';
    admision_for_session:string='';
    admissionFees:string='';
    tuitionFees:string='';
    tuitionFeesApril:string='';
    tuitionFeesJune:string='';
    tuitionFeesNovember	:string='';
    busfees:string='';
    busFeesApril:string='';
    busFeesJune:string='';
    busFeesNovember:string='';
    admissionForm:string='';
    childKit:string='';
    paid:string="";
    outstand:string='';
    student_fees:string='';
    pramoted:string='';
    note:string='';
    tution_fees_paid:string="";
    bus_fees_paid:string="";
    paidFeespaid:string='';
    admissionFormPaid:string='';
    admissionFeesPaid:string='';
    
 
}
