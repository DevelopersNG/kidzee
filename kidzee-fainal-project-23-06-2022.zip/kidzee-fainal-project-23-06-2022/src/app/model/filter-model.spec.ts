import { FilterModel } from './filter-model';

describe('FilterModel', () => {
  it('should create an instance', () => {
    expect(new FilterModel()).toBeTruthy();
  });
});
