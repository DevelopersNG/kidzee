import { StudentShow } from './student-show';

describe('StudentShow', () => {
  it('should create an instance', () => {
    expect(new StudentShow()).toBeTruthy();
  });
});
