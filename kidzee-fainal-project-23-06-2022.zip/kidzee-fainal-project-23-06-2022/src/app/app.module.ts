import { Component, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegistrationComponent } from './component/registration/registration.component';
import { StudentfeeComponent } from './component/studentfee/studentfee.component';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { NgxPrintModule } from 'ngx-print';
import { HomeComponent } from './home/home.component';
import { StudentdataComponent } from './component/studentdata/studentdata.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { NgxSpinnerModule } from "ngx-spinner";
// import { StudentdataComponent } from './component/studentdata/studentdata.component';




@NgModule({
  declarations: [
    AppComponent,
    RegistrationComponent,
    StudentfeeComponent,
    HomeComponent,
    StudentdataComponent,
    // StudentdataComponent,

  
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    RouterModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgxPrintModule,
    NgxPaginationModule,
    NgxSpinnerModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {

 }
