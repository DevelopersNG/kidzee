package com.kidzee.model;

import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name="images")
public class UploadImagesModel {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(name = "student_id")
	private int studentId;

	@Column(name = "image", length = 1000)
	private byte[] image;	
	
	@Column(name = "image_name")
	private String image_name;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public byte[] getImage() {
		return image;
	}

	public void setImage(byte[] image) {
		this.image = image;
	}

	public String getImage_name() {
		return image_name;
	}

	public void setImage_name(String image_name) {
		this.image_name = image_name;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public UploadImagesModel() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "UploadImagesModel [id=" + id + ", studentId=" + studentId + ", image=" + Arrays.toString(image)
				+ ", image_name=" + image_name + "]";
	}

	public UploadImagesModel(int id, int studentId, byte[] image, String image_name) {
		super();
		this.id = id;
		this.studentId = studentId;
		this.image = image;
		this.image_name = image_name;
	}
	
	
	public UploadImagesModel(int id,String image_name, byte[] image ) {
		this.studentId = id;
		this.image_name = image_name;
		this.image = image;
	}
	
	
	
	
}
