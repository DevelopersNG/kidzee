package com.kidzee.controller;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

import org.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.kidzee.model.FeesModel;
import com.kidzee.model.RegistreationModel;
import com.kidzee.model.UploadImagesModel;
import com.kidzee.repository.UploadImagesRepository;
import com.kidzee.service.AddRegistreationService;
import com.kidzee.service.UploadImagesService;


@CrossOrigin("*")
//@CrossOrigin(origins = "http://localhost:4200" , methods = {RequestMethod.OPTIONS, RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE}, allowedHeaders = "*", allowCredentials = "true")
@RestController 
@RequestMapping("/api")
public class StudentRegisterComponent {

	@Autowired
    private AddRegistreationService addRegistreationService;
	
	@Autowired
    private UploadImagesService uploadImagesService;
	
	@Autowired
	private UploadImagesRepository uploadImagesRepository;


		
	@PostMapping(path = "/student/update/{id}")
	public Map<String, String> updateStudent(@Validated @RequestBody RegistreationModel registreationModel, @PathVariable("id") String id) {
		  HashMap<String, String> map = new HashMap<>();
		  registreationModel.setId(Integer.parseInt(id));
		  // first check is student available , if available then update records other wise insert records
		  if(addRegistreationService.updateExitingStudent(registreationModel,Integer.parseInt(id)) !=null) {
			  map.put("message", id); 
			  map.put("success", "yes"); 
			  System.out.println("latest_updated_id- " + id);
		}else {
			map.put("success", "No"); 
			map.put("message", "Something wrong , please try again....");
		}
		return map;
	}
	
	@PostMapping(path = "/student/insert")
	public Map<String, String> insertStudent(@Validated @RequestBody RegistreationModel registreationModel) {
		  HashMap<String, String> map = new HashMap<>();
//		  registreationModel.setId(Integer.parseInt(id));
		  int id;
		  // first check is student available , if available then update records other wise insert records
		  if(addRegistreationService.UpdateStudentRegistration(registreationModel) !=null) {
			  String latest_insterted_id=addRegistreationService.getStudentID(registreationModel);
			  map.put("message", latest_insterted_id); 
			  map.put("success", "yes"); 
			  System.out.println("latest_insterted_id- " + latest_insterted_id);
		}else {
			 map.put("success", "No"); 
			map.put("message", "Something wrong , please try again....");
		}
		return map;
	}
	
	
	@PostMapping(path = "/student/fees/update/{id}")
	public Map<String, String> updateStudentFees(@Validated @RequestBody FeesModel feesModel, @PathVariable("id") String id) {
		  HashMap<String, String> map = new HashMap<>();
		  feesModel.setStudent_id(Integer.parseInt(id));
		  
		  if(addRegistreationService.updateStudentFees(feesModel,Integer.parseInt(id)) !=null) {
			 map.put("message", "Student Updated..."); 
		}else {
			map.put("message", "Something wrong , please try again....");
		}
		return map;
	}

	@PostMapping("/student/pramoted/{id}")
	public Map<String, String> update_Studentpramoted(@Validated @RequestBody RegistreationModel registreationModel,  FeesModel feesModel,@PathVariable("id") int id) {
		HashMap<String, String> map = new HashMap<>();
		
		  // promoted
		Optional<RegistreationModel> obj=addRegistreationService.getAllStudentList(id);
		String latest_id= addRegistreationService.updateStudentPramoted(registreationModel,obj,id);
		if(latest_id !=null && !latest_id.equals("")) {
			
//			Optional<FeesModel> objFees=addRegistreationService.getStudentFeesList(id);
//			if(addRegistreationService.getStudentFeesList(latest_id,objFees,feesModel)!=null) {
//				 map.put("message", "Student Updated..."); 
//				 map.put("Student_ID", latest_id); 
//			}
			
			if(addRegistreationService.insertStudentFeesList(latest_id)!=null) {
			 map.put("message", "Student Updated..."); 
			 map.put("Student_ID", latest_id); 
		}
		}else {
			map.put("message", "Something wrong , please try again....");
		}
		return map;
	}
	
	@GetMapping("/student/get/{id}")
	public Map<String, String> getStudentByID(@PathVariable("id") String id) {
		 HashMap<String, String> map = new HashMap<>();
		 map=addRegistreationService.getStudentByID(Integer.parseInt(id));
		 if(map==null) {
			 map.put("message","something wrong ! record not fetch...");
		 }
		 return map;
	}
	
	@GetMapping("/student/get/fees/outstanding/{id}")
	public Map<String, String> getStudentFeesOutstandingByID(@PathVariable("id") String id) {
		 HashMap<String, String> map = new HashMap<>();
		 map=addRegistreationService.getStudentFeesOutstandingByID(Integer.parseInt(id));
		 if(map==null) {
			 map.put("message","something wrong ! record not fetch...");
		 }
		 return map;
	}
	
	
	@GetMapping("/student/get/fees/print/{id}")
	public Map<String, String> getStudentFeesPrintByID(@PathVariable("id") String id) {
		 HashMap<String, String> map = new HashMap<>();
		 map=addRegistreationService.getStudentFeesPrintByID(Integer.parseInt(id));
		 if(map==null) {
			 map.put("message","something wrong ! record not fetch...");
		 }
		 return map;
	}
	
	@PostMapping(value = "/student/get/filter")
	public String getStudentByFilter(@Validated @RequestBody RegistreationModel registreationModel) {
		 JSONArray jsonResultArray = new JSONArray();
		 HashMap<String,String> map=new HashMap<String, String>();
		 jsonResultArray=addRegistreationService.getStudentByFilter(registreationModel);
		System.out.println(jsonResultArray.toString());
		 return jsonResultArray.toString();
	}
	
//	@PostMapping("/student/upload/images/{id}")
//	@RequestMapping(value = "/student/upload/images/{id}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
//    public BodyBuilder  uplaodImage(@RequestParam("imagef") LinkedList<MultipartFile> payload,@PathVariable("id") String id) throws IOException{
//		 HashMap<String, String> map = new HashMap<>();
//		 MultipartFile file = payload.get(0);
//		 map=uploadImagesService.uploadStudentImage(file,Integer.parseInt(id));
//		 if(map==null) {
//			 map.put("message","something wrong ! photo not uploaded...");
//		 }
//		 return (BodyBuilder) ResponseEntity.status(HttpStatus.OK);
//    }
	
	
	@RequestMapping(value = "/student/upload/images/{id}", method = RequestMethod.POST, consumes = MediaType.ALL_VALUE)
	      public Map<String, String> uplaodImage(@RequestParam("imageFile") MultipartFile file,@PathVariable("id") String id) throws IOException {
	          System.out.println("Original Image Byte Size - " + file.getBytes().length);
	          System.out.println("file name- "+file.getOriginalFilename());
	          HashMap<String, String> map = new HashMap<>();
	          UploadImagesModel img = new UploadImagesModel(Integer.parseInt(id), file.getOriginalFilename(),file.getBytes());
	          UploadImagesModel img1= uploadImagesRepository.save(img);
	          if(img1!=null) {
	        	  map.put("message","success");
	          }
	          return map;
	      }
	
	@RequestMapping(value = "/student/get/images/{id}", method = RequestMethod.GET, consumes = MediaType.ALL_VALUE)
    public UploadImagesModel getImage(@PathVariable("id") String id) throws IOException {
       
		final Optional<UploadImagesModel> retrievedImage = uploadImagesRepository.findByStudentId(Integer.parseInt(id));
		System.out.println(retrievedImage.get().getId());
        System.out.println(retrievedImage.get().getImage_name());
        System.out.println(retrievedImage.get().getStudentId());
        System.out.println(decompressBytes(retrievedImage.get().getImage()));
		UploadImagesModel img=new UploadImagesModel (retrievedImage.get().getStudentId(),retrievedImage.get().getImage_name(),retrievedImage.get().getImage());
		return img;
    }
	  
	
	@PostMapping(path = "/student/deleted/{student_id}/{fees_id}")
	public Map<String, String> deletedStudentRecords(@PathVariable("student_id") String student_id,@PathVariable("fees_id") String fees_id,@Validated @RequestBody RegistreationModel registreationModel) {
		  HashMap<String, String> map = new HashMap<>();
		  FeesModel feesModel=new FeesModel();
		  if(addRegistreationService.deleteStudentRecords(registreationModel,Integer.parseInt(student_id)) !=null) {
			  if(addRegistreationService.deleteFeesRecords(feesModel,Integer.parseInt(fees_id)) !=null) {
					 map.put("message", "Student deleted..."); 				  
			  }else {
			map.put("message", "Something wrong , please try again....");
		}
		  }
		return map;
	}

	 public static byte[] compressBytes(byte[] data) {
		          Deflater deflater = new Deflater();
		          deflater.setInput(data);
		          deflater.finish();
		          ByteArrayOutputStream outputStream = new ByteArrayOutputStream(data.length);
		          byte[] buffer = new byte[1024];
		          while (!deflater.finished()) {
		              int count = deflater.deflate(buffer);
		              outputStream.write(buffer, 0, count);
		          }
		          try {
		              outputStream.close();
		          } catch (IOException e) {
		          }
		          deflater.end();
		          System.out.println("Compressed Image Byte Size - " + outputStream.toByteArray().length);
		          return outputStream.toByteArray();
		      }

	// uncompress the image bytes before returning it to the angular application
	  public static byte[] decompressBytes(byte[] data) {
		          Inflater inflater = new Inflater();
		          inflater.setInput(data);
		          ByteArrayOutputStream outputStream = new ByteArrayOutputStream(data.length);
		          byte[] buffer = new byte[1024];
		          try {
		              while (!inflater.finished()) {
		                  int count = inflater.inflate(buffer);
		                  outputStream.write(buffer, 0, count);
		              }
		              outputStream.close();
		          } catch (IOException ioe) {
		          } catch (DataFormatException e) {
		          }
		          return outputStream.toByteArray();
		      }
	  
	  
	  
}

