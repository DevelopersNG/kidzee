package com.kidzee.repository;
import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.kidzee.model.RegistreationModel;

@Repository
public interface RegistrationRepository extends JpaRepository<RegistreationModel, Integer> {

	@Transactional
	@Query(value="select id from student where child_id= :childID and delete_flag='N'",nativeQuery = true)
	String findByChild_id(String childID);
	
	@Transactional
	@Modifying
	@Query(value=" update student set  child_id= :child_id, aadhar_number= :aadhar_number, admision_for_session= :admision_for_session, name= :name, gender= :gender, "
			+ "dob= :dob,age= :age, place_of_birth= :place_of_birth, mother_tonge= :mother_tonge, nationnality= :nationnality, sche_cast= :sche_cast, religion= :religion, cast= :cast, "
			+ "father_name= :father_name, mother_name= :mother_name, postal_address= :postal_address, mobile_number= :mobile_number,"
			+ " whatapp_number= :whatapp_number, email_id= :email_id, guardian_name= :guardian_name, relationship= :relationship,"
			+ " first_postal_address= :first_postal_address, year= :year, class_name= :class_name,"
			+ "bank_name= :bank_name, ac_no= :ac_no,ifsc_code= :ifsc_code,bus_status= :bus_status,place_name= :place_name, bus_number= :bus_number, sssm_id= :sssm_id"
			+ " where id= :id and delete_flag= :delete_flag ",nativeQuery= true)
	Object updateStudent(int id,String child_id, String aadhar_number, String admision_for_session, String name, String gender,
			String dob, String age, String place_of_birth, String mother_tonge, String nationnality, String sche_cast,
			String religion, String cast ,String father_name, String mother_name, String postal_address, String mobile_number,
			String whatapp_number, String email_id, String guardian_name, String relationship,
			String first_postal_address, String class_name, String year, String delete_flag,String bank_name,String ac_no,String ifsc_code,String bus_status,String place_name,String bus_number,String sssm_id);

	
	@Transactional
	@Modifying	
	@Query(value="update student set delete_flag='Y' where id= :studentID and delete_flag='N'",nativeQuery = true)
	Object deleteStudentRecords(int studentID);

}
