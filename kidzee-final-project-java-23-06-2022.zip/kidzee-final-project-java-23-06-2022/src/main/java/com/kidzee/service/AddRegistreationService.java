package com.kidzee.service;

import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import org.json.JSONArray;

import com.kidzee.model.FeesModel;
import com.kidzee.model.RegistreationModel;

public interface AddRegistreationService {

	Object UpdateStudentRegistration(RegistreationModel registreationModel);

	Object updateStudentFees(FeesModel feesModel, int id);

	HashMap<String, String> getStudentID(int i);

	Optional<RegistreationModel> getAllStudentList(int id);

	String updateStudentPramoted(RegistreationModel registreationModel, Optional<RegistreationModel> obj, int id);

	Object updatePromotedStudnetFees(int id);

	Optional<FeesModel> getStudentFeesList(int id);

	Object getStudentFeesList(String id, Optional<FeesModel> objFees, FeesModel feesModel);

	String getStudentID(RegistreationModel registreationModel);

	HashMap<String, String> getStudentByID(int parseInt);

	JSONArray getStudentByFilter(RegistreationModel registreationModel);

	Object updateExitingStudent(RegistreationModel registreationModel, int parseInt);

	Object insertStudentFeesList(String latest_id);

	Object deleteStudentRecords(RegistreationModel registreationModel, int parseInt);

	Object deleteFeesRecords(FeesModel feesModel, int parseInt);

	HashMap<String, String> getStudentFeesOutstandingByID(int parseInt);

	HashMap<String, String> getStudentFeesPrintByID(int parseInt);

	

}
