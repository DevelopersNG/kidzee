package com.kidzee.service;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.kidzee.model.UploadImagesModel;
import com.kidzee.repository.UploadImagesRepository;

@Service
public class UploadImagesServiceImpl implements UploadImagesService {

	@Autowired
	private UploadImagesRepository uploadImagesRepository;


	
	@Override
	public HashMap<String, String> uploadStudentImage(MultipartFile file, int parseInt) {
	
//		return uploadImagesRepository.save();
		
		return null;
		 
	}

}
