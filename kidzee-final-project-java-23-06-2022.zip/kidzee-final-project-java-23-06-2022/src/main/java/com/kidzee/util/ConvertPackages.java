package com.kidzee.util;

public class ConvertPackages {
	
	public String convertNullToBlank(String value) {
		if(value!=null && !value.equals("") && !value.equals("null")) {
			return value;
		}
		return "";
	}
	
	public String convertNullToZero(String value) {
		if(value!=null && !value.equals("") && !value.equals("null")) {
			return value;
		}
		return "0";
	}
}
