package com.kidzee.repository;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.kidzee.model.FeesModel;

public interface StudentFeesRepository extends JpaRepository<FeesModel, Integer>{


	@Transactional
	@Query(value="select * from student_fees where student_id= :ID",nativeQuery = true )
	Optional<FeesModel> findByStudentId(int ID);

//	@Transactional
//	@Modifying
//	@Query(value="insert into student_fees (student_id, bus_status, total_fees, paid, outstand, note, student_fees) values ( :student_id ,"
//			+ ":bus_status, :total_fees, :paid , :outstand ,:note ,:student_fees  )",nativeQuery = true )
//	Object saveStudentFees(String student_id, String bus_status, String total_fees, String paid, String outstand,
//			String note, String student_fees);

	@Transactional
	@Modifying
	@Query(value="insert into student_fees (student_id, bus_status, total_fees, paid, outstand, note, student_fees,"
			+ "child_kit_fees,admission_form_fees,admission_fees,tution_fees,tution_april_fees,tution_june_fees,tution_november_fees,"
			+ "bus_fees,bus_april_fees,bus_june_fees,bus_november_fees,bus_fees_paid,tution_fees_paid) values"
			+ " ( :latest_id,:bus_status, :total_fees, :paid , :outstand ,:note ,:student_fees,"
			+ " :child_kit_fees,:admission_form_fees,:admission_fees,:tution_fees,:tution_april_fees,:tution_june_fees,:tution_november_fees, "
			+ ":bus_fees,:bus_april_fees,:bus_june_fees,:bus_november_fees,bus_fees_paid= :bus_fees_paid, tution_fees_paid= :tution_fees_paid)",nativeQuery = true )
	Object saveStudentFees(String latest_id, String bus_status, String total_fees, String paid, String outstand,
			String note, String student_fees, String child_kit_fees, String admission_form_fees, String admission_fees,
			String tution_fees, String tution_april_fees, String tution_june_fees, String tution_november_fees,
			String bus_fees, String bus_april_fees, String bus_june_fees, String bus_november_fees,String bus_fees_paid,String tution_fees_paid);

	
	@Transactional
	@Modifying
	@Query(value="insert into student_fees (student_id) values (:latest_id)",nativeQuery = true)
	Object insertLatestPromotedRecords(String latest_id);

	
	@Transactional
	@Modifying
	@Query(value="update student_fees set delete_flag='Y' where id= :fees_id and delete_flag='N'",nativeQuery = true)
	Object deleteFeesDetails(int fees_id);


}
