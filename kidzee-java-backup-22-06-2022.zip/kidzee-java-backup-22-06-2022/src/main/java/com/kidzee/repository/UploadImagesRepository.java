package com.kidzee.repository;

import java.util.HashMap;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.kidzee.model.UploadImagesModel;

@Repository
public interface UploadImagesRepository extends JpaRepository<UploadImagesModel, Integer>{

	Optional<UploadImagesModel> findById(int id);

	Optional<UploadImagesModel> findByStudentId(int id);


}
