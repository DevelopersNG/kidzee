
package com.kidzee.model;

import javax.annotation.Generated;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;


@Entity
@Table(name="student")
public class RegistreationModel {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	private String child_id;
	
	private String aadhar_number;
	
	private String admision_for_session;

	private String name;

	private String gender;
	
	private String dob;
	
	private String age;
	
	private String mother_tonge;
	
	private String nationnality;

	private String sche_cast;

	private String religion;
	
	private String cast;
	
	private String father_name;
	
    private String mother_name;
	
	private String postal_address;

	private String mobile_number;

	private String whatapp_number;
	
	private String email_id;
	
	private String guardian_name;

	private String relationship;

	private String first_postal_address;
	
	private String class_name;
	 
	private String year;
	
	private String place_of_birth;
	
	private String bank_name;
	private String ac_no;
	private String ifsc_code;
	private String bus_status;
	private String place_name;
	
	private String bus_number;
	
	private String sssm_id;
	
	
	@Transient
	private String search_form_date;

	@Transient
	private String search_to_date;
	
	@Transient
	private String pramoted;
	
	public String getSearch_form_date() {
		return search_form_date;
	}

	public void setSearch_form_date(String search_form_date) {
		this.search_form_date = search_form_date;
	}

	public String getSearch_to_date() {
		return search_to_date;
	}

	public void setSearch_to_date(String search_to_date) {
		this.search_to_date = search_to_date;
	}

	public String getBank_name() {
		return bank_name;
	}

	public void setBank_name(String bank_name) {
		this.bank_name = bank_name;
	}

	public String getAc_no() {
		return ac_no;
	}

	public void setAc_no(String ac_no) {
		this.ac_no = ac_no;
	}

	public String getIfsc_code() {
		return ifsc_code;
	}

	public void setIfsc_code(String ifsc_code) {
		this.ifsc_code = ifsc_code;
	}

	public String getBus_status() {
		return bus_status;
	}

	public void setBus_status(String bus_status) {
		this.bus_status = bus_status;
	}

	public String getPlace_name() {
		return place_name;
	}

	public void setPlace_name(String place_name) {
		this.place_name = place_name;
	}

	public String getPlace_of_birth() {
		return place_of_birth;
	}

	public void setPlace_of_birth(String place_of_birth) {
		this.place_of_birth = place_of_birth;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getChild_id() {
		return child_id;
	}

	public String getMobile_number() {
		return mobile_number;
	}

	public void setMobile_number(String mobile_number) {
		this.mobile_number = mobile_number;
	}

	public String getClass_name() {
		return class_name;
	}

	public void setClass_name(String class_name) {
		this.class_name = class_name;
	}

	public void setChild_id(String child_id) {
		this.child_id = child_id;
	}

	public String getAadhar_number() {
		return aadhar_number;
	}

	public void setAadhar_number(String aadhar_number) {
		this.aadhar_number = aadhar_number;
	}

	public String getAdmision_for_session() {
		return admision_for_session;
	}

	public void setAdmision_for_session(String admision_for_session) {
		this.admision_for_session = admision_for_session;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getMother_tonge() {
		return mother_tonge;
	}

	public void setMother_tonge(String mother_tonge) {
		this.mother_tonge = mother_tonge;
	}

	public String getNationnality() {
		return nationnality;
	}

	public void setNationnality(String nationnality) {
		this.nationnality = nationnality;
	}

	public String getSche_cast() {
		return sche_cast;
	}

	public void setSche_cast(String sche_cast) {
		this.sche_cast = sche_cast;
	}

	public String getReligion() {
		return religion;
	}

	public void setReligion(String religion) {
		this.religion = religion;
	}

	public String getCast() {
		return cast;
	}

	public void setCast(String cast) {
		this.cast = cast;
	}

	public String getFather_name() {
		return father_name;
	}

	public void setFather_name(String father_name) {
		this.father_name = father_name;
	}

	public String getMother_name() {
		return mother_name;
	}

	public void setMother_name(String mother_name) {
		this.mother_name = mother_name;
	}

	public String getPostal_address() {
		return postal_address;
	}

	public void setPostal_address(String postal_address) {
		this.postal_address = postal_address;
	}


	public String getWhatapp_number() {
		return whatapp_number;
	}

	public void setWhatapp_number(String whatapp_number) {
		this.whatapp_number = whatapp_number;
	}

	public String getEmail_id() {
		return email_id;
	}

	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}

	public String getGuardian_name() {
		return guardian_name;
	}

	public void setGuardian_name(String guardian_name) {
		this.guardian_name = guardian_name;
	}

	public String getRelationship() {
		return relationship;
	}

	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}


	public String getFirst_postal_address() {
		return first_postal_address;
	}

	public void setFirst_postal_address(String first_postal_address) {
		this.first_postal_address = first_postal_address;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public RegistreationModel() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public String getPramoted() {
		return pramoted;
	}

	public void setPramoted(String pramoted) {
		this.pramoted = pramoted;
	}

	public String getBus_number() {
		return bus_number;
	}

	public void setBus_number(String bus_number) {
		this.bus_number = bus_number;
	}

	public String getSssm_id() {
		return sssm_id;
	}

	public void setSssm_id(String sssm_id) {
		this.sssm_id = sssm_id;
	}

	@Override
	public String toString() {
		return "RegistreationModel [id=" + id + ", child_id=" + child_id + ", aadhar_number=" + aadhar_number
				+ ", admision_for_session=" + admision_for_session + ", name=" + name + ", gender=" + gender + ", dob="
				+ dob + ", age=" + age + ", mother_tonge=" + mother_tonge + ", nationnality=" + nationnality
				+ ", sche_cast=" + sche_cast + ", religion=" + religion + ", cast=" + cast + ", father_name="
				+ father_name + ", mother_name=" + mother_name + ", postal_address=" + postal_address
				+ ", mobile_number=" + mobile_number + ", whatapp_number=" + whatapp_number + ", email_id=" + email_id
				+ ", guardian_name=" + guardian_name + ", relationship=" + relationship + ", first_postal_address="
				+ first_postal_address + ", class_name=" + class_name + ", year=" + year + ", place_of_birth="
				+ place_of_birth + ", bank_name=" + bank_name + ", ac_no=" + ac_no + ", ifsc_code=" + ifsc_code
				+ ", bus_status=" + bus_status + ", place_name=" + place_name + ", bus_number=" + bus_number
				+ ", sssm_id=" + sssm_id + ", pramoted=" + pramoted + ", getBank_name()=" + getBank_name()
				+ ", getAc_no()=" + getAc_no() + ", getIfsc_code()=" + getIfsc_code() + ", getBus_status()="
				+ getBus_status() + ", getPlace_name()=" + getPlace_name() + ", getPlace_of_birth()="
				+ getPlace_of_birth() + ", getId()=" + getId() + ", getChild_id()=" + getChild_id()
				+ ", getMobile_number()=" + getMobile_number() + ", getClass_name()=" + getClass_name()
				+ ", getAadhar_number()=" + getAadhar_number() + ", getAdmision_for_session()="
				+ getAdmision_for_session() + ", getName()=" + getName() + ", getGender()=" + getGender()
				+ ", getDob()=" + getDob() + ", getAge()=" + getAge() + ", getMother_tonge()=" + getMother_tonge()
				+ ", getNationnality()=" + getNationnality() + ", getSche_cast()=" + getSche_cast() + ", getReligion()="
				+ getReligion() + ", getCast()=" + getCast() + ", getFather_name()=" + getFather_name()
				+ ", getMother_name()=" + getMother_name() + ", getPostal_address()=" + getPostal_address()
				+ ", getWhatapp_number()=" + getWhatapp_number() + ", getEmail_id()=" + getEmail_id()
				+ ", getGuardian_name()=" + getGuardian_name() + ", getRelationship()=" + getRelationship()
				+ ", getFirst_postal_address()=" + getFirst_postal_address() + ", getYear()=" + getYear()
				+ ", getPramoted()=" + getPramoted() + ", getBus_number()=" + getBus_number() + ", getSssm_id()="
				+ getSssm_id() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}

	public RegistreationModel(Integer id, String child_id, String aadhar_number, String admision_for_session,
			String name, String gender, String dob, String age, String mother_tonge, String nationnality,
			String sche_cast, String religion, String cast, String father_name, String mother_name,
			String postal_address, String mobile_number, String whatapp_number, String email_id, String guardian_name,
			String relationship, String first_postal_address, String class_name, String year, String place_of_birth,
			String bank_name, String ac_no, String ifsc_code, String bus_status, String place_name, String bus_number,
			String sssm_id, String pramoted) {
		super();
		this.id = id;
		this.child_id = child_id;
		this.aadhar_number = aadhar_number;
		this.admision_for_session = admision_for_session;
		this.name = name;
		this.gender = gender;
		this.dob = dob;
		this.age = age;
		this.mother_tonge = mother_tonge;
		this.nationnality = nationnality;
		this.sche_cast = sche_cast;
		this.religion = religion;
		this.cast = cast;
		this.father_name = father_name;
		this.mother_name = mother_name;
		this.postal_address = postal_address;
		this.mobile_number = mobile_number;
		this.whatapp_number = whatapp_number;
		this.email_id = email_id;
		this.guardian_name = guardian_name;
		this.relationship = relationship;
		this.first_postal_address = first_postal_address;
		this.class_name = class_name;
		this.year = year;
		this.place_of_birth = place_of_birth;
		this.bank_name = bank_name;
		this.ac_no = ac_no;
		this.ifsc_code = ifsc_code;
		this.bus_status = bus_status;
		this.place_name = place_name;
		this.bus_number = bus_number;
		this.sssm_id = sssm_id;
		this.pramoted = pramoted;
	}



	

	
	
	
	
}
