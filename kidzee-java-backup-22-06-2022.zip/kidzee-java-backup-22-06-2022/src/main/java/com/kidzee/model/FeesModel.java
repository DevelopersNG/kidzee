package com.kidzee.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="student_fees")
public class FeesModel {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	private int student_id;

	private String bus_status;

	private String total_fees;
	
	private String paid;
	
	private String outstand;
	
	private String student_fees;

	// new
	private String child_kit_fees;
	
	private String admission_form_fees;
	
	private String admission_fees;
	
	private String tution_fees;
	
	private String tution_april_fees;
	
	private String tution_june_fees;
	
	private String tution_november_fees;
	
	private String bus_fees;
	
	private String bus_april_fees;
	
	private String bus_june_fees;
	
	private String bus_november_fees;

	private String note;
	
	private String tution_fees_paid;
	
	private String bus_fees_paid;
	
	private String admission_form_paid;
	
	private String admission_fees_paid;
	
	@Transient
	private String placeName; 
	

	public String getAdmission_form_paid() {
		return admission_form_paid;
	}

	public void setAdmission_form_paid(String admission_form_paid) {
		this.admission_form_paid = admission_form_paid;
	}

	public String getAdmission_fees_paid() {
		return admission_fees_paid;
	}

	public void setAdmission_fees_paid(String admission_fees_paid) {
		this.admission_fees_paid = admission_fees_paid;
	}

	public String getPlaceName() {
		return placeName;
	}

	public void setPlaceName(String placeName) {
		this.placeName = placeName;
	}

	public String getChild_kit_fees() {
		return child_kit_fees;
	}

	public void setChild_kit_fees(String child_kit_fees) {
		this.child_kit_fees = child_kit_fees;
	}

	public String getAdmission_form_fees() {
		return admission_form_fees;
	}

	public void setAdmission_form_fees(String admission_form_fees) {
		this.admission_form_fees = admission_form_fees;
	}

	public String getAdmission_fees() {
		return admission_fees;
	}

	public void setAdmission_fees(String admission_fees) {
		this.admission_fees = admission_fees;
	}

	public String getTution_fees() {
		return tution_fees;
	}

	public String getTution_fees_paid() {
		return tution_fees_paid;
	}

	public void setTution_fees_paid(String tution_fees_paid) {
		this.tution_fees_paid = tution_fees_paid;
	}

	public String getBus_fees_paid() {
		return bus_fees_paid;
	}

	public void setBus_fees_paid(String bus_fees_paid) {
		this.bus_fees_paid = bus_fees_paid;
	}

	public void setTution_fees(String tution_fees) {
		this.tution_fees = tution_fees;
	}

	public String getTution_april_fees() {
		return tution_april_fees;
	}

	public void setTution_april_fees(String tution_april_fees) {
		this.tution_april_fees = tution_april_fees;
	}

	public String getTution_june_fees() {
		return tution_june_fees;
	}

	public void setTution_june_fees(String tution_june_fees) {
		this.tution_june_fees = tution_june_fees;
	}

	public String getTution_november_fees() {
		return tution_november_fees;
	}

	public void setTution_november_fees(String tution_november_fees) {
		this.tution_november_fees = tution_november_fees;
	}

	public String getBus_fees() {
		return bus_fees;
	}

	public void setBus_fees(String bus_fees) {
		this.bus_fees = bus_fees;
	}

	public String getBus_april_fees() {
		return bus_april_fees;
	}

	public void setBus_april_fees(String bus_april_fees) {
		this.bus_april_fees = bus_april_fees;
	}

	public String getBus_june_fees() {
		return bus_june_fees;
	}

	public void setBus_june_fees(String bus_june_fees) {
		this.bus_june_fees = bus_june_fees;
	}

	public String getBus_november_fees() {
		return bus_november_fees;
	}

	public void setBus_november_fees(String bus_november_fees) {
		this.bus_november_fees = bus_november_fees;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getStudent_id() {
		return student_id;
	}

	public void setStudent_id(int student_id) {
		this.student_id = student_id;
	}

	public String getBus_status() {
		return bus_status;
	}

	public void setBus_status(String bus_status) {
		this.bus_status = bus_status;
	}

	public String getTotal_fees() {
		return total_fees;
	}

	public void setTotal_fees(String total_fees) {
		this.total_fees = total_fees;
	}

	public String getPaid() {
		return paid;
	}

	public void setPaid(String paid) {
		this.paid = paid;
	}

	public String getOutstand() {
		return outstand;
	}

	public void setOutstand(String outstand) {
		this.outstand = outstand;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public String getStudent_fees() {
		return student_fees;
	}

	public void setStudent_fees(String student_fees) {
		this.student_fees = student_fees;
	}
	
	
	
	public FeesModel() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "FeesModel [id=" + id + ", student_id=" + student_id + ", bus_status=" + bus_status + ", total_fees="
				+ total_fees + ", paid=" + paid + ", outstand=" + outstand + ", student_fees=" + student_fees
				+ ", child_kit_fees=" + child_kit_fees + ", admission_form_fees=" + admission_form_fees
				+ ", admission_fees=" + admission_fees + ", tution_fees=" + tution_fees + ", tution_april_fees="
				+ tution_april_fees + ", tution_june_fees=" + tution_june_fees + ", tution_november_fees="
				+ tution_november_fees + ", bus_fees=" + bus_fees + ", bus_april_fees=" + bus_april_fees
				+ ", bus_june_fees=" + bus_june_fees + ", bus_november_fees=" + bus_november_fees + ", note=" + note
				+ ", tution_fees_paid=" + tution_fees_paid + ", bus_fees_paid=" + bus_fees_paid + ", placeName="
				+ placeName + "]";
	}

	public FeesModel(int id, int student_id, String bus_status, String total_fees, String paid, String outstand,
			String student_fees, String child_kit_fees, String admission_form_fees, String admission_fees,
			String tution_fees, String tution_april_fees, String tution_june_fees, String tution_november_fees,
			String bus_fees, String bus_april_fees, String bus_june_fees, String bus_november_fees, String note,
			String tution_fees_paid, String bus_fees_paid, String placeName) {
		super();
		this.id = id;
		this.student_id = student_id;
		this.bus_status = bus_status;
		this.total_fees = total_fees;
		this.paid = paid;
		this.outstand = outstand;
		this.student_fees = student_fees;
		this.child_kit_fees = child_kit_fees;
		this.admission_form_fees = admission_form_fees;
		this.admission_fees = admission_fees;
		this.tution_fees = tution_fees;
		this.tution_april_fees = tution_april_fees;
		this.tution_june_fees = tution_june_fees;
		this.tution_november_fees = tution_november_fees;
		this.bus_fees = bus_fees;
		this.bus_april_fees = bus_april_fees;
		this.bus_june_fees = bus_june_fees;
		this.bus_november_fees = bus_november_fees;
		this.note = note;
		this.tution_fees_paid = tution_fees_paid;
		this.bus_fees_paid = bus_fees_paid;
		this.placeName = placeName;
	}

	




}
