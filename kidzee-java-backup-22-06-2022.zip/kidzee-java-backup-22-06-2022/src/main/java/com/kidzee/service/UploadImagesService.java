package com.kidzee.service;

import java.util.HashMap;

import org.springframework.web.multipart.MultipartFile;

public interface UploadImagesService {

	HashMap<String, String> uploadStudentImage(MultipartFile file, int parseInt);

}
