package com.kidzee.service;

import java.math.BigDecimal;
import java.text.Format.Field;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kidzee.model.FeesModel;
import com.kidzee.model.RegistreationModel;
import com.kidzee.repository.RegistrationRepository;
import com.kidzee.repository.StudentFeesRepository;
import com.kidzee.util.ConvertPackages;

@Service
public class AddRegistreationServiceImpl implements AddRegistreationService{

	@Autowired
	private RegistrationRepository registrationRepository;

	@Autowired
	private StudentFeesRepository studentFeesRepository;
	
	
	
	@PersistenceContext
	private EntityManager em;
	
	@Override
	public Object UpdateStudentRegistration(RegistreationModel registreationModel) {
		return registrationRepository.save(registreationModel);
	}

	@Override
	public Object updateStudentFees(FeesModel feesModel, int id) {
		return studentFeesRepository.save(feesModel);
	}

	@Override
	public String getStudentID(RegistreationModel registreationModel) {
		return registrationRepository.findByChild_id(registreationModel.getChild_id());
	}

	@Override
	public Optional<RegistreationModel> getAllStudentList(int id) {
		return registrationRepository.findById(id);
	}

	@Override
	public String updateStudentPramoted(RegistreationModel registreationModel, Optional<RegistreationModel> obj,
			int id) {
		ConvertPackages utils=new ConvertPackages();
		if(obj.isPresent()) {
			RegistreationModel newRegistreationModel=obj.get();
			registreationModel.setChild_id(utils.convertNullToBlank(newRegistreationModel.getChild_id()));
			registreationModel.setAadhar_number(utils.convertNullToBlank(newRegistreationModel.getAadhar_number()));
			registreationModel.setAdmision_for_session(utils.convertNullToBlank(newRegistreationModel.getAdmision_for_session()));
			registreationModel.setName(utils.convertNullToBlank(newRegistreationModel.getName()));
			registreationModel.setGender(utils.convertNullToBlank(newRegistreationModel.getGender()));
			registreationModel.setDob(utils.convertNullToBlank(newRegistreationModel.getDob()));
			registreationModel.setAge(utils.convertNullToBlank(newRegistreationModel.getAge()));
			registreationModel.setMother_tonge(utils.convertNullToBlank(newRegistreationModel.getMother_tonge()));
			registreationModel.setNationnality(utils.convertNullToBlank(newRegistreationModel.getNationnality()));
			registreationModel.setSche_cast(utils.convertNullToBlank(newRegistreationModel.getSche_cast()));
			registreationModel.setReligion(utils.convertNullToBlank(newRegistreationModel.getReligion()));
			registreationModel.setFather_name(utils.convertNullToBlank(newRegistreationModel.getFather_name()));
			registreationModel.setMother_name(utils.convertNullToBlank(newRegistreationModel.getMother_name()));
			registreationModel.setPostal_address(utils.convertNullToBlank(newRegistreationModel.getPostal_address()));
			registreationModel.setMobile_number(utils.convertNullToBlank(newRegistreationModel.getMobile_number()));
			registreationModel.setWhatapp_number(utils.convertNullToBlank(newRegistreationModel.getWhatapp_number()));
			registreationModel.setEmail_id(utils.convertNullToBlank(newRegistreationModel.getEmail_id()));
			registreationModel.setGuardian_name(utils.convertNullToBlank(newRegistreationModel.getGuardian_name()));
			registreationModel.setRelationship(utils.convertNullToBlank(newRegistreationModel.getRelationship()));
			registreationModel.setFirst_postal_address(utils.convertNullToBlank(newRegistreationModel.getFirst_postal_address()));
			registreationModel.setClass_name(utils.convertNullToBlank(newRegistreationModel.getClass_name()));
			registreationModel.setYear(utils.convertNullToBlank(newRegistreationModel.getYear()));
			registreationModel.setPlace_of_birth(utils.convertNullToBlank(newRegistreationModel.getPlace_of_birth()));
			
			registreationModel.setCast(utils.convertNullToBlank(newRegistreationModel.getCast()));
			registreationModel.setBank_name(utils.convertNullToBlank(newRegistreationModel.getBank_name()));
			registreationModel.setIfsc_code(utils.convertNullToBlank(newRegistreationModel.getIfsc_code()));
			registreationModel.setAc_no(utils.convertNullToBlank(newRegistreationModel.getAc_no()));
			registreationModel.setBus_status(utils.convertNullToBlank(newRegistreationModel.getBus_status()));
			registreationModel.setPlace_name(utils.convertNullToBlank(newRegistreationModel.getPlace_name()));
			
			registreationModel.setSssm_id(utils.convertNullToBlank(newRegistreationModel.getSssm_id()));
			registreationModel.setBus_number(utils.convertNullToBlank(newRegistreationModel.getBus_number()));
		}
		
		 // set year
		  String[] arraySplit=registreationModel.getYear().split("-");
		  int current_year= Integer.parseInt(arraySplit[1]);
		  int next_year= Integer.parseInt(arraySplit[1])+1;
		  String acedemic_year=current_year+"-"+next_year;
		  registreationModel.setYear(acedemic_year);
		  
  	  // set class
		  if(registreationModel.getPramoted()!=null && !registreationModel.getPramoted().equals("")) {
			  if(registreationModel.getPramoted().equals("promoted")) {
				  if(registreationModel.getClass_name().equals("Play Group")) {
					  registreationModel.setClass_name("Nursery");
				  }else if(registreationModel.getClass_name().equals("Nursery")) {
					  registreationModel.setClass_name("Jr.KG");
				  }else if(registreationModel.getClass_name().equals("Jr.KG")) {
					  registreationModel.setClass_name("Sr.KG");
				  }
			}else if(registreationModel.getPramoted().equals("school shift")) {
				// school shift table
			}else if(registreationModel.getPramoted().equals("failed")) {
				// student failed table
			}
		  }
		Object value=null;
		Object myobject =registrationRepository.saveAndFlush(registreationModel);
		int idd=0;
		
		try {
			java.lang.reflect.Field myField = myobject.getClass().getDeclaredField("id");
			myField.setAccessible(true);
			value= myField.get(myobject);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return value+"";
	}

	@Override
	public Object updatePromotedStudnetFees(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<FeesModel> getStudentFeesList(int id) {
		return studentFeesRepository.findByStudentId(id);
	}

	@Override
	public Object getStudentFeesList(String latest_id, Optional<FeesModel> objFees, FeesModel feesModels) {
		ConvertPackages utils=new ConvertPackages();
		String student_id="" , bus_status="", total_fees="", paid="", outstand="", note="",student_fees="";
		String admission_form_fees="",child_kit_fees="",admission_fees="",tution_fees="",tution_april_fees="",tution_june_fees="",tution_november_fees="";
		String bus_fees="",bus_april_fees="",bus_june_fees="",bus_november_fees="", tution_fees_paid="", bus_fees_paid="";
		if(objFees.isPresent()) {
			feesModels=objFees.get();
		 student_id= utils.convertNullToBlank(""+latest_id);
		 bus_status= utils.convertNullToBlank(""+feesModels.getBus_status());
		 total_fees= utils.convertNullToBlank(""+feesModels.getTotal_fees());
		 paid= utils.convertNullToBlank(""+feesModels.getPaid());
		 outstand= utils.convertNullToBlank(""+feesModels.getOutstand());
		 note= utils.convertNullToBlank(""+feesModels.getNote());
		 student_fees= utils.convertNullToBlank(""+feesModels.getStudent_fees());
		
		 //new  tution
		 child_kit_fees=utils.convertNullToBlank(""+feesModels.getChild_kit_fees());
		 admission_form_fees=utils.convertNullToBlank(""+feesModels.getAdmission_form_fees());
		 admission_fees=utils.convertNullToBlank(""+feesModels.getAdmission_fees());
		 tution_fees=utils.convertNullToBlank(""+feesModels.getTution_fees());
		 tution_april_fees=utils.convertNullToBlank(""+feesModels.getTution_april_fees());
		 tution_june_fees=utils.convertNullToBlank(""+feesModels.getTution_june_fees());
		 tution_november_fees=utils.convertNullToBlank(""+feesModels.getTution_november_fees());
		 
		 //bus
		 bus_fees=utils.convertNullToBlank(""+feesModels.getBus_fees());
		 bus_april_fees=utils.convertNullToBlank(""+feesModels.getBus_april_fees());
		 bus_june_fees=utils.convertNullToBlank(""+feesModels.getBus_june_fees());
		 bus_november_fees=utils.convertNullToBlank(""+feesModels.getBus_november_fees());
		
		 bus_fees_paid=utils.convertNullToBlank(""+feesModels.getBus_fees_paid());
		 tution_fees_paid=utils.convertNullToBlank(""+feesModels.getTution_fees_paid());
		
		}
		
		Object myobject =studentFeesRepository.saveStudentFees(latest_id,bus_status,total_fees,paid,outstand,note,student_fees,
				child_kit_fees,admission_form_fees,admission_fees,tution_fees,tution_april_fees,tution_june_fees,tution_november_fees,
				bus_fees,bus_april_fees,bus_june_fees,bus_november_fees,bus_fees_paid,tution_fees_paid);

		return myobject;
	}

	@Override
	public HashMap<String, String> getStudentID(int i) {
		// TODO Auto-generated method stub
		return null;
	}

	
	@Override
	@Transactional
	public HashMap<String, String> getStudentByID(int id) {
		HashMap<String, String> map = new HashMap<>();
		ConvertPackages utils=new ConvertPackages();
		String columnName=getAllColumnName();
			try {
			Query q = em.createNativeQuery("SELECT " + columnName + "  FROM student as s "
					+ " join student_fees as fee on s.id=fee.student_id"
					+ " where s.id= :id and s.delete_flag='N'");
			
			q.setParameter("id", id);
			boolean status = false;
			List<Object[]> results = q.getResultList();
			if (results != null) {
				for (Object[] obj : results) {
					int i = 0;
					
					//first row
					map.put("student_id", utils.convertNullToBlank(String.valueOf(obj[i]))); 
					map.put("child_id", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("aadhar_number", utils.convertNullToBlank(String.valueOf(obj[++i])));
//					map.put("admision_for_session", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("name", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("gender", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("dob", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("age", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("place_of_birth", utils.convertNullToBlank(String.valueOf(obj[++i])));
					
//						8					
					map.put("mother_tonge", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("nationnality", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("sche_cast", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("religion", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("cast", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("father_name", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("mother_name", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("postal_address", utils.convertNullToBlank(String.valueOf(obj[++i])));
					
//					6
					map.put("mobile_number", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("whatapp_number", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("email_id", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("guardian_name", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("relationship", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("first_postal_address", utils.convertNullToBlank(String.valueOf(obj[++i])));
					
//					3
					map.put("create_date", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("year", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("class_name", utils.convertNullToBlank(String.valueOf(obj[++i])));
					
//					5
					map.put("bank_name", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("ac_no", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("ifsc_code", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("bus_status", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("place_name", utils.convertNullToBlank(String.valueOf(obj[++i])));
					
					//2
					map.put("bus_number", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("sssm_id", utils.convertNullToBlank(String.valueOf(obj[++i])));
			
//					, fee., fee., fee.outstand, fee.note, fee.student_fees, fee.create_date as fee_create_data, fee.child_kit_fees,
										
//					9
					map.put("fee_id", utils.convertNullToBlank(String.valueOf(obj[++i])));
//					map.put("fee", utils.convertNullToBlank(String.valueOf(obj[++i])));
//					map.put("bus_status", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("total_fees", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("paid", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("outstand", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("note", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("student_fees", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("fees_create_date", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("child_kit_fees", utils.convertNullToBlank(String.valueOf(obj[++i])));
				
//					5	
					map.put("admission_form_fees", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("admission_fees", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("tution_fees", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("tution_april_fees", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("tution_june_fees", utils.convertNullToBlank(String.valueOf(obj[++i])));
					
//					5
					map.put("tution_november_fees", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("bus_fees", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("bus_april_fees", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("bus_june_fees", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("bus_november_fees", utils.convertNullToBlank(String.valueOf(obj[++i])));
					
					map.put("bus_fees_paid",utils.convertNullToBlank(String.valueOf(obj[++i])));
				   map.put("tution_fees_paid",utils.convertNullToBlank(String.valueOf(obj[++i])));
			

				}
			}
//			map=getValueByFieldsName(results);
			
//			if (status == false) {
//				map.put("message", "record not found");
//			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return map;
	}

	private HashMap<String, String> getValueByFieldsName(List<Object[]> results) {
		HashMap<String, String> map = new HashMap<>();
		ConvertPackages utils=new ConvertPackages();
		try {
			if (results != null) {
				for (Object[] obj : results) {
					int i = 0;
					
					//first row
					map.put("student_id", utils.convertNullToBlank(String.valueOf(obj[i]))); 
					map.put("child_id", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("aadhar_number", utils.convertNullToBlank(String.valueOf(obj[++i])));
//					map.put("admision_for_session", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("name", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("gender", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("dob", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("age", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("place_of_birth", utils.convertNullToBlank(String.valueOf(obj[++i])));
					
//						8					
					map.put("mother_tonge", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("nationnality", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("sche_cast", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("religion", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("cast", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("father_name", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("mother_name", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("postal_address", utils.convertNullToBlank(String.valueOf(obj[++i])));
					
//					6
					map.put("mobile_number", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("whatapp_number", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("email_id", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("guardian_name", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("relationship", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("first_postal_address", utils.convertNullToBlank(String.valueOf(obj[++i])));
					
//					3
					map.put("create_date", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("year", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("class_name", utils.convertNullToBlank(String.valueOf(obj[++i])));
					
//					5
					map.put("bank_name", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("ac_no", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("ifsc_code", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("bus_status", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("place_name", utils.convertNullToBlank(String.valueOf(obj[++i])));
				
//					, fee., fee., fee.outstand, fee.note, fee.student_fees, fee.create_date as fee_create_data, fee.child_kit_fees,
										
//					9
					map.put("fee_id", utils.convertNullToBlank(String.valueOf(obj[++i])));
//					map.put("fee", utils.convertNullToBlank(String.valueOf(obj[++i])));
//					map.put("bus_status", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("total_fees", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("paid", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("outstand", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("note", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("student_fees", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("fees_create_date", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("child_kit_fees", utils.convertNullToBlank(String.valueOf(obj[++i])));
				
//					5	
					map.put("admission_form_fees", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("admission_fees", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("tution_fees", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("tution_april_fees", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("tution_june_fees", utils.convertNullToBlank(String.valueOf(obj[++i])));
					
//					5
					map.put("tution_november_fees", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("bus_fees", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("bus_april_fees", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("bus_june_fees", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("bus_november_fees", utils.convertNullToBlank(String.valueOf(obj[++i])));
				    map.put("bus_number", utils.convertNullToBlank(String.valueOf(obj[++i])));
					map.put("sssm_id", utils.convertNullToBlank(String.valueOf(obj[++i])));
					
			

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return map;
	}

	private String getAllColumnName() {
		return "s.id as stud_id, s.child_id, s.aadhar_number, s.name, s.gender, s.dob, s.age, s.place_of_birth,"
				+ " s.mother_tonge, s.nationnality, s.sche_cast, s.religion, s.cast, s.father_name, s.mother_name, s.postal_address,"
				+ " s.mobile_number, s.whatapp_number, s.email_id, s.guardian_name, s.relationship, s.first_postal_address,"
				+ " s.create_date as stud_create_date, s.year, s.class_name,"
				+ "s.bank_name,s.ac_no,s.ifsc_code,s.bus_status as bus_service,s.place_name as bus_place,s.bus_number,s.sssm_id,"
				+ "fee.id as fee_id, fee.total_fees, fee.paid, fee.outstand, fee.note, fee.student_fees, fee.create_date as fee_create_data, fee.child_kit_fees,"
				+ "fee.admission_form_fees, fee.admission_fees, fee.tution_fees, fee.tution_april_fees, fee.tution_june_fees,"
				+ " fee.tution_november_fees, fee.bus_fees, fee.bus_april_fees, fee.bus_june_fees, fee.bus_november_fees,fee.bus_fees_paid,fee.tution_fees_paid";
	}

	@Override
	public JSONArray getStudentByFilter(RegistreationModel registreationModel) {
		HashMap<String, String> map = new HashMap<>();
		String columnName= "s.id as stud_id, s.child_id, s.aadhar_number, s.name, s.gender, s.dob, s.age, s.place_of_birth,"
		+ " s.mother_tonge, s.nationnality, s.sche_cast, s.religion, s.cast, s.father_name, s.mother_name, s.postal_address,"
		+ " s.mobile_number, s.whatapp_number, s.email_id, s.guardian_name, s.relationship, s.first_postal_address,"
		+ " s.create_date as stud_create_date, s.year, s.class_name,"
		+ "s.bank_name,s.ac_no,s.ifsc_code,s.bus_status as bus_service,s.place_name as bus_place,s.bus_number,s.sssm_id";
		
		String studentFees= "fee.id as fee_id, fee.total_fees, fee.paid, fee.outstand, fee.note, fee.student_fees, fee.create_date as fee_create_data, fee.child_kit_fees,"
		+ "fee.admission_form_fees, fee.admission_fees, fee.tution_fees, fee.tution_april_fees, fee.tution_june_fees,"
		+ " fee.tution_november_fees, fee.bus_fees, fee.bus_april_fees, fee.bus_june_fees, fee.bus_november_fees,fee.bus_fees_paid,fee.tution_fees_paid,fee.admission_form_paid,fee.admission_fees_paid";
		
		JSONArray resultArray = new JSONArray();
			try {
			
				String whereClause="";
				if(registreationModel.getChild_id()!=null && !registreationModel.getChild_id().equals("")) {
					whereClause= whereClause+ " and s.child_id='"+registreationModel.getChild_id().trim()+"'";
				}
				if(registreationModel.getYear()!=null && !registreationModel.getYear().equals("") && !registreationModel.getYear().equals("Select")) {
					whereClause= whereClause+ " and s.year='"+registreationModel.getYear()+"'";
				}
				if(registreationModel.getClass_name()!=null && !registreationModel.getClass_name().equals("") && !registreationModel.getClass_name().equals("Select")) {
					whereClause= whereClause+ " and s.class_name='"+registreationModel.getClass_name()+"'";
				}
				
				String student_paid_fees_ids="",student_id_for_final_total="";
				
				String feesWhereClause="";
				// code for date search
				if(registreationModel.getSearch_form_date()!=null && !registreationModel.getSearch_form_date().equals("") && registreationModel.getSearch_to_date()!=null && !registreationModel.getSearch_to_date().equals("")) {
//					whereClause= whereClause+ " and date(s.create_date)>=date('"+registreationModel.getSearch_form_date().trim()+"') and date(s.create_date)<=date('"+registreationModel.getSearch_to_date().trim()+"')";
					student_paid_fees_ids=getDateWisePaymentStudentFeesID(registreationModel.getSearch_form_date(),registreationModel.getSearch_to_date());
					
					feesWhereClause= feesWhereClause+ " and date(create_date)>=date('"+registreationModel.getSearch_form_date().trim()+"') and date(create_date)<=date('"+registreationModel.getSearch_to_date().trim()+"')";
				}else if(registreationModel.getSearch_form_date()!=null && !registreationModel.getSearch_form_date().equals("") && (registreationModel.getSearch_to_date()==null || registreationModel.getSearch_to_date().equals(""))) {
//					whereClause= whereClause+ " and date(s.create_date)>=date('"+registreationModel.getSearch_form_date().trim()+"')";
					student_paid_fees_ids=getDateWisePaymentStudentFeesID(registreationModel.getSearch_form_date(),"");
					feesWhereClause= feesWhereClause+ " and date(create_date)>=date('"+registreationModel.getSearch_form_date().trim()+"')";
				}else if((registreationModel.getSearch_form_date()==null || registreationModel.getSearch_form_date().equals("")) && registreationModel.getSearch_to_date()!=null && !registreationModel.getSearch_to_date().equals("")) {
//					whereClause= whereClause+ " and date(s.create_date)=date('"+registreationModel.getSearch_to_date().trim()+"')";
					student_paid_fees_ids=getDateWisePaymentStudentFeesID("",registreationModel.getSearch_to_date());
					feesWhereClause= feesWhereClause+ " and date(create_date)=date('"+registreationModel.getSearch_to_date().trim()+"')";
				}else {
					whereClause="";
				}
				
				if(!student_paid_fees_ids.equals("")) {
					whereClause=" and s.id in ("+student_paid_fees_ids+")";
				}
				
			BigDecimal output=new BigDecimal("0"); 	
			BigDecimal final_fees=new BigDecimal("0");
			BigDecimal final_outstand_fees=new BigDecimal("0");
			BigDecimal final_paid_fees=new BigDecimal("0");

			
				System.out.println("SELECT " + columnName + "  FROM student as s "
					+ " where  s.delete_flag='N' "+ whereClause +"/");
				
				Query q = em.createNativeQuery("SELECT " + columnName + "  FROM student as s "
					+ " where  s.delete_flag='N' "+ whereClause +"");
//					+ " where  s.delete_flag='N' "+ whereClause +" order by fee.create_date  desc limit 1");
			ConvertPackages utils=new ConvertPackages();
			boolean status = false;
			List<Object[]> results = q.getResultList();
			if (results != null) {
				for (Object[] obj : results) {
					int i = 0;
					JSONObject json = new JSONObject();
					//first row 8
					int studentID=Integer.parseInt(String.valueOf(obj[i]));
					student_id_for_final_total=student_id_for_final_total+","+studentID;
					json.put("student_id", studentID); 
					json.put("child_id", utils.convertNullToBlank(String.valueOf(obj[++i])));
					json.put("aadhar_number", utils.convertNullToBlank(String.valueOf(obj[++i])));
//					json.put("admision_for_session", utils.convertNullToBlank(String.valueOf(obj[++i])));
					json.put("name", utils.convertNullToBlank(String.valueOf(obj[++i])));
					json.put("gender", utils.convertNullToBlank(String.valueOf(obj[++i])));
					json.put("dob", utils.convertNullToBlank(String.valueOf(obj[++i])));
					json.put("age", utils.convertNullToBlank(String.valueOf(obj[++i])));
					json.put("place_of_birth", utils.convertNullToBlank(String.valueOf(obj[++i])));
					
//						8					
					json.put("mother_tonge", utils.convertNullToBlank(String.valueOf(obj[++i])));
					json.put("nationnality", utils.convertNullToBlank(String.valueOf(obj[++i])));
					json.put("sche_cast", utils.convertNullToBlank(String.valueOf(obj[++i])));
					json.put("religion", utils.convertNullToBlank(String.valueOf(obj[++i])));
					json.put("cast", utils.convertNullToBlank(String.valueOf(obj[++i])));
					json.put("father_name", utils.convertNullToBlank(String.valueOf(obj[++i])));
					json.put("mother_name", utils.convertNullToBlank(String.valueOf(obj[++i])));
					json.put("postal_address", utils.convertNullToBlank(String.valueOf(obj[++i])));
					
//					6
					json.put("mobile_number", utils.convertNullToBlank(String.valueOf(obj[++i])));
					json.put("whatapp_number", utils.convertNullToBlank(String.valueOf(obj[++i])));
					json.put("email_id", utils.convertNullToBlank(String.valueOf(obj[++i])));
					json.put("guardian_name", utils.convertNullToBlank(String.valueOf(obj[++i])));
					json.put("relationship", utils.convertNullToBlank(String.valueOf(obj[++i])));
					json.put("first_postal_address", utils.convertNullToBlank(String.valueOf(obj[++i])));
					
//					3
					json.put("create_date", utils.convertNullToBlank(String.valueOf(obj[++i])));
					json.put("year", utils.convertNullToBlank(String.valueOf(obj[++i])));
					json.put("class_name", utils.convertNullToBlank(String.valueOf(obj[++i])));
					
//					5
					json.put("bank_name", utils.convertNullToBlank(String.valueOf(obj[++i])));
					json.put("ac_no", utils.convertNullToBlank(String.valueOf(obj[++i])));
					json.put("ifsc_code", utils.convertNullToBlank(String.valueOf(obj[++i])));
					json.put("bus_status", utils.convertNullToBlank(String.valueOf(obj[++i])));
					json.put("place_name", utils.convertNullToBlank(String.valueOf(obj[++i])));
				
					json.put("bus_number", utils.convertNullToBlank(String.valueOf(obj[++i])));
					json.put("sssm_id", utils.convertNullToBlank(String.valueOf(obj[++i])));
					// Fees Query
					
					
								
					System.out.println("student id- "+"SELECT SUM(paid),SUM(bus_fees_paid),SUM(tution_fees_paid),SUM(admission_form_paid),SUM(admission_fees_paid)  FROM student_fees"
							+ " where  student_id="+studentID+" and delete_flag='N'");
					Query queryTotalFees = em.createNativeQuery("SELECT SUM(paid),SUM(bus_fees_paid),SUM(tution_fees_paid),SUM(admission_form_paid),SUM(admission_fees_paid)  FROM student_fees"
							+ " where  student_id="+studentID+" and delete_flag='N'");
//							+ " where  s.delete_flag='N' "+ whereClause +" order by fee.create_date  desc limit 1");
					List<Object[]> resultsTotalPaids = queryTotalFees.getResultList();
					if (resultsTotalPaids != null) {
						for (Object[] objTotalFees : resultsTotalPaids) {
							i=0;
							double paid= Double.parseDouble(utils.convertNullToZero(String.valueOf(objTotalFees[i])));
							double bus_paid= Double.parseDouble(utils.convertNullToZero(String.valueOf(objTotalFees[++i])));
							double tution_paid= Double.parseDouble(utils.convertNullToZero(String.valueOf(objTotalFees[++i])));
							double admission_form_paid= Double.parseDouble(utils.convertNullToZero(String.valueOf(objTotalFees[++i])));
							double admission_fee_paid= Double.parseDouble(utils.convertNullToZero(String.valueOf(objTotalFees[++i])));
							double total=paid+bus_paid+tution_paid+admission_form_paid+admission_fee_paid;
							
							BigDecimal bg=new BigDecimal(total);
							final_paid_fees=final_paid_fees.add(bg);
							json.put("total_paid", total);
							}
						}
					
					
					
					Query queryFees = em.createNativeQuery("SELECT " + studentFees + "  FROM student_fees as fee "
							+ " where  student_id="+studentID+" and delete_flag='N' order by  create_date desc limit 1");
					List<Object[]> resultsFees = queryFees.getResultList();
					if (resultsFees != null) {
						for (Object[] objFees : resultsFees) {
							i=0;
//							9
							json.put("fee_id", utils.convertNullToBlank(String.valueOf(objFees[i])));
//							json.put("fee", utils.convertNullToBlank(String.valueOf(obj[++i])));
//							json.put("bus_status", utils.convertNullToBlank(String.valueOf(obj[++i])));
							
							String total_fees=utils.convertNullToBlank(String.valueOf(objFees[++i]));
							json.put("total_fees", total_fees);
							
							BigDecimal _a = new BigDecimal(total_fees);
							final_fees =final_fees.add(_a);
							
							
							int paid=Integer.parseInt(utils.convertNullToZero(String.valueOf(objFees[++i])));
							json.put("paid", paid);
							
							String outstand=utils.convertNullToBlank(String.valueOf(objFees[++i]));
							json.put("outstand", outstand);
							
							BigDecimal _d = new BigDecimal(outstand);							
							final_outstand_fees=final_outstand_fees.add(_d);
							
							json.put("note", utils.convertNullToBlank(String.valueOf(objFees[++i])));
							json.put("student_fees", utils.convertNullToBlank(String.valueOf(objFees[++i])));
							json.put("fees_create_date", utils.convertNullToBlank(String.valueOf(objFees[++i])));
							json.put("child_kit_fees", utils.convertNullToBlank(String.valueOf(objFees[++i])));
						
//							5	
							json.put("admission_form_fees", utils.convertNullToBlank(String.valueOf(objFees[++i])));
							json.put("admission_fees", utils.convertNullToBlank(String.valueOf(objFees[++i])));
							json.put("tution_fees", utils.convertNullToBlank(String.valueOf(objFees[++i])));
							json.put("tution_april_fees", utils.convertNullToBlank(String.valueOf(objFees[++i])));
							json.put("tution_june_fees", utils.convertNullToBlank(String.valueOf(objFees[++i])));
							
//							5
							json.put("tution_november_fees", utils.convertNullToBlank(String.valueOf(objFees[++i])));
							json.put("bus_fees", utils.convertNullToBlank(String.valueOf(objFees[++i])));
							json.put("bus_april_fees", utils.convertNullToBlank(String.valueOf(objFees[++i])));
							json.put("bus_june_fees", utils.convertNullToBlank(String.valueOf(objFees[++i])));
							json.put("bus_november_fees", utils.convertNullToBlank(String.valueOf(objFees[++i])));

							int bus_paid=Integer.parseInt(utils.convertNullToZero(String.valueOf(objFees[++i])));
							int tution_paid=Integer.parseInt(utils.convertNullToZero(String.valueOf(objFees[++i])));

							
							json.put("bus_fees_paid", bus_paid);
							json.put("tution_fees_paid", tution_paid);

						
							int admission_form_paid=Integer.parseInt(utils.convertNullToZero(String.valueOf(objFees[++i])));
							int admission_fees_paid=Integer.parseInt(utils.convertNullToZero(String.valueOf(objFees[++i])));
							json.put("admission_form_paid", admission_form_paid);
							json.put("admission_fees_paid", admission_fees_paid);
							json.put("total_paid_fees", paid+bus_paid+tution_paid+admission_fees_paid+admission_form_paid);							
						}
					}					
					
					// for other details
					JSONArray arr=new JSONArray();
					JSONArray arrBus=new JSONArray();
					JSONArray arrTution=new JSONArray();
					Query queryOthersFees = em.createNativeQuery("SELECT date(create_date) as date,paid,admission_form_paid,admission_fees_paid,bus_fees_paid,tution_fees_paid FROM student_fees  "
							+ " where  student_id="+studentID+" and delete_flag='N' "+feesWhereClause+"");
					List<Object[]> resultsOtherFees = queryOthersFees.getResultList();
					if (resultsOtherFees != null) {
						for (Object[] objOtherFees : resultsOtherFees) {
							int k=0;
							String other_date=utils.convertNullToBlank(String.valueOf(objOtherFees[k]));
							int other_installment=Integer.parseInt(utils.convertNullToZero(String.valueOf(objOtherFees[++k])));
							int admission_form_paid=  Integer.parseInt(utils.convertNullToZero(String.valueOf(objOtherFees[++k])));
							int admission_fees_paid=Integer.parseInt(utils.convertNullToZero(String.valueOf(objOtherFees[++k])));
							int bus_fees=Integer.parseInt(utils.convertNullToZero(String.valueOf(objOtherFees[++k])));
							int tutions_fees=Integer.parseInt(utils.convertNullToZero(String.valueOf(objOtherFees[++k])));
							
							int sum=	other_installment+	admission_form_paid+admission_fees_paid;
									
							if(other_installment!=0) {
								JSONObject objResultsOtherJson=new JSONObject();
								objResultsOtherJson.put("other_date",other_date);
								objResultsOtherJson.put("Other_Installment",sum);
								arr.put(objResultsOtherJson);
							}
							
							if(bus_fees!=0) {
								JSONObject objResultsBusJson=new JSONObject();
								objResultsBusJson.put("bus_date",other_date);
								objResultsBusJson.put("bus_Installment",bus_fees);
								arrBus.put(objResultsBusJson);
							}
							
							if(tutions_fees!=0) {
								JSONObject objResultsTutionJson=new JSONObject();
								objResultsTutionJson.put("tution_date",other_date);
								objResultsTutionJson.put("tution_Installment",tutions_fees);
								arrTution.put(objResultsTutionJson);
							}
						}
					}
					
					json.put("data", arr);
					json.put("bus", arrBus);
					json.put("tution", arrTution);
					
					
					resultArray.put(json);

				}
			}
			
			
			
			System.out.println("final - " + "SELECT SUM(paid),SUM(bus_fees_paid),SUM(tution_fees_paid),SUM(admission_form_paid),SUM(admission_fees_paid) FROM student_fees where student_id in ("+student_paid_fees_ids+") and delete_flag='N' "+feesWhereClause+"");
			
			
			String whereQuery="";
			if(!student_id_for_final_total.equals("")) {
				student_id_for_final_total=student_id_for_final_total.replaceFirst(",", "");
				whereQuery=" student_id in ("+student_id_for_final_total+") ";
			}
			
			Query querySUMFees = em.createNativeQuery("SELECT SUM(paid),SUM(bus_fees_paid),SUM(tution_fees_paid),SUM(admission_form_paid),SUM(admission_fees_paid) FROM student_fees"
					+ " where "+whereQuery+" and delete_flag='N' "+feesWhereClause+"");
//					+ " where  s.delete_flag='N' "+ whereClause +" order by fee.create_date  desc limit 1");
			List<Object[]> resultsSUMPaids = querySUMFees.getResultList();
			JSONObject jsonFinalTotal = new JSONObject();
			if (resultsSUMPaids != null) {
				for (Object[] objSumFees : resultsSUMPaids) {
					int i=0;
					i=0;
					double paid= Double.parseDouble(utils.convertNullToZero(String.valueOf(objSumFees[i])));
					double bus_paid= Double.parseDouble(utils.convertNullToZero(String.valueOf(objSumFees[++i])));
					double tution_paid= Double.parseDouble(utils.convertNullToZero(String.valueOf(objSumFees[++i])));
					double admission_form_paid= Double.parseDouble(utils.convertNullToZero(String.valueOf(objSumFees[++i])));
					double admission_fee_paid= Double.parseDouble(utils.convertNullToZero(String.valueOf(objSumFees[++i])));
					double total=paid+bus_paid+tution_paid+admission_form_paid+admission_fee_paid;
//					jsonFinalTotal.put("final_total_paid", final_paid_fees);
					
					jsonFinalTotal.put("final_total_paid", final_paid_fees);
					jsonFinalTotal.put("final_fees", final_fees);
					jsonFinalTotal.put("final_outstand_fees", final_outstand_fees);
					}
				}
			
			resultArray.put(jsonFinalTotal);			
			
			
//			map=getValueByFieldsName(results);
//			if (status == false) {
//				map.put("message", "record not found");
//			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return resultArray;
	}

	private String getDateWisePaymentStudentFeesID(String search_form_date, String search_to_date) {
		String ids="",whereClause="";
		try {
			ConvertPackages utils=new ConvertPackages();
			String l_strQuery="";
			if(search_form_date!=null && !search_form_date.equals("") && search_to_date!=null && !search_to_date.equals("")) {
				whereClause= whereClause+ " and date(create_date)>=date('"+search_form_date.trim()+"') and date(create_date)<=date('"+search_to_date.trim()+"')";
			}
			
			if(search_form_date!=null && !search_form_date.equals("") && (search_to_date==null || search_to_date.equals(""))) {
				whereClause= whereClause+ " and date(create_date)>=date('"+search_form_date.trim()+"')";
			}
			
			if((search_form_date==null || search_form_date.equals("")) && search_to_date!=null && !search_to_date.equals("")) {
				whereClause= whereClause+ " and date(create_date)=date('"+search_to_date.trim()+"')";
			}

			
			Query queryTotalFees = em.createNativeQuery("SELECT group_concat(distinct(student_id))  FROM student_fees where  delete_flag='N' "+ whereClause +"");
				ids=utils.convertNullToBlank(queryTotalFees.getSingleResult().toString());			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return ids;
	}

	@Override
	public Object updateExitingStudent(RegistreationModel registreationModel, int ID) {
		boolean temp=false;
		ConvertPackages utils=new ConvertPackages();
			int count = 0;
			try {
				Query q = em.createNativeQuery("SELECT count(*) as count FROM student where id= :ID and delete_flag='N'");
				q.setParameter("ID", ID);
				count = Integer.parseInt(q.getSingleResult().toString());
				
				String child_id="",aadhar_number="",admision_for_session="",name="",gender="",dob="",age="",place_of_birth="",mother_tonge="",
						nationnality="",sche_cast="",religion="",father_name="",mother_name="",postal_address="",mobile_number="",
						whatapp_number="",email_id="",guardian_name="",relationship="",first_postal_address="",class_name="",year="",
						cast="",bank_name="",ac_no="",ifsc_code="",bus_status="",placeName="", bus_number="",sssm_id="";
				
				if(count>0) {
					// update the student
					child_id= registreationModel.getChild_id();
					aadhar_number=utils.convertNullToBlank(registreationModel.getAadhar_number());
					admision_for_session=utils.convertNullToBlank(registreationModel.getAdmision_for_session());
					name=utils.convertNullToBlank(registreationModel.getName());
					gender=utils.convertNullToBlank(registreationModel.getGender());
					dob=utils.convertNullToBlank(registreationModel.getDob());
					age= utils.convertNullToBlank(registreationModel.getAge());
					place_of_birth=utils.convertNullToBlank(registreationModel.getPlace_of_birth());
					mother_tonge=utils.convertNullToBlank(registreationModel.getMother_tonge());
					nationnality=utils.convertNullToBlank(registreationModel.getNationnality());
					sche_cast=utils.convertNullToBlank(registreationModel.getSche_cast());
					religion= utils.convertNullToBlank(registreationModel.getReligion());
					cast= utils.convertNullToBlank(registreationModel.getCast());
					father_name= utils.convertNullToBlank(registreationModel.getFather_name());
					mother_name=utils.convertNullToBlank(registreationModel.getMother_name());
					postal_address=utils.convertNullToBlank(registreationModel.getPostal_address());
					mobile_number=utils.convertNullToBlank(registreationModel.getMobile_number());
					whatapp_number=utils.convertNullToBlank(registreationModel.getWhatapp_number());
					email_id=utils.convertNullToBlank(registreationModel.getEmail_id());
					guardian_name=utils.convertNullToBlank(registreationModel.getGuardian_name());
					relationship=utils.convertNullToBlank(registreationModel.getRelationship());
					first_postal_address=utils.convertNullToBlank(registreationModel.getFirst_postal_address());
					class_name=utils.convertNullToBlank(registreationModel.getClass_name());
					year=utils.convertNullToBlank(registreationModel.getYear());
					
					bank_name=utils.convertNullToBlank(registreationModel.getBank_name());
					ac_no=utils.convertNullToBlank(registreationModel.getAc_no());
					ifsc_code=utils.convertNullToBlank(registreationModel.getIfsc_code());
					bus_status=utils.convertNullToBlank(registreationModel.getBus_status());
					placeName=utils.convertNullToBlank(registreationModel.getPlace_name());
				
					bus_number=utils.convertNullToBlank(registreationModel.getBus_number());
					sssm_id=utils.convertNullToBlank(registreationModel.getSssm_id());
					
					String delete_flag="N";
					Object check=registrationRepository.updateStudent(ID,child_id,aadhar_number,admision_for_session,name,gender,dob,age,place_of_birth,mother_tonge,
						nationnality,sche_cast,religion,cast,father_name,mother_name,postal_address,mobile_number,
						whatapp_number,email_id,guardian_name,relationship,first_postal_address,class_name,year,delete_flag,
						bank_name,ac_no,ifsc_code,bus_status,placeName,bus_number,sssm_id);
					
					if(check!=null) {
						temp=true;
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		
		return temp;
	}

	@Override
	public Object insertStudentFeesList(String latest_id) {
		return studentFeesRepository.insertLatestPromotedRecords(latest_id);
	}

	@Override
	public Object deleteStudentRecords(RegistreationModel registreationModel, int studentID) {
		return registrationRepository.deleteStudentRecords(studentID);
	}

	@Override
	public Object deleteFeesRecords(FeesModel feesModel, int fees_id) {
		return studentFeesRepository.deleteFeesDetails(fees_id);
	}

	@Override
	public HashMap<String, String> getStudentFeesOutstandingByID(int studentID) {
		HashMap<String, String> map = new HashMap<>();
		ConvertPackages utils=new ConvertPackages();
		try {
			Query queryFees = em.createNativeQuery("SELECT  fee.outstand, fee.note  FROM student_fees as fee "
					+ " where  student_id="+studentID+" and delete_flag='N' order by  create_date desc limit 1");
			List<Object[]> resultsFees = queryFees.getResultList();
			if (resultsFees != null) {
				for (Object[] objFees : resultsFees) {
					int i=0;
					map.put("outstanding", utils.convertNullToZero(String.valueOf(objFees[i])));
					map.put("note", utils.convertNullToZero(String.valueOf(objFees[++i])));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return map;
	}
}