import { HttpClient } from '@angular/common/http';
import { Component, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Fees } from 'src/app/model/fees.model';
import { StudentService } from 'src/app/service/student.service';
import { NgxSpinnerService } from 'ngx-spinner';
import * as $ from 'jquery';

@Component({
  selector: 'app-studentfee',
  templateUrl: './studentfee.component.html',
  styleUrls: ['./studentfee.component.css']
})
export class StudentfeeComponent implements OnInit, OnChanges {
  data: any;
  finalTotal: any;
  tempFinalTotal: any;
  Outstand: any;
  student_id: any;

  retrievedImage: any;
  base64Data: any;
  retrieveResonse: any;
  show: any;

  constructor(private router: Router, private route: ActivatedRoute, private studentService: StudentService, private http: HttpClient,
    private spinner: NgxSpinnerService) {
    this.route.paramMap.subscribe(params => {



      // this.className = params.get("className");
      // this.place_name = params.get("place_name");
      // this.student_id = params.get("id");
      // this.student_id = params.get("pramoted");
      // this.year=params.get("year");
      // this.setFeesData(this.className,this.place_name); 
    });
  }
  ngOnChanges(changes: SimpleChanges): void {

  }

  className: any;
  place_name: any;
  year: any;

  ngOnInit(): void {
    this.route.queryParams.subscribe((params => {
      // alert("fees id- "+ this.route.snapshot.paramMap.get('id'));
      this.data = JSON.parse(atob(params['data']));
      this.className = this.data.class_name;
      this.place_name = this.data.place_name;
      this.student_id = this.route.snapshot.paramMap.get('id');
      this.year = this.data.year;
      this.setFeesData(this.className, this.place_name);
      this.isEditableShown = true;
      this.viewImage(this.student_id);
      this.getOutstandingFees(this.student_id)
    }))

  }
  getOutstandingFees(student_id: any) {

    this.studentService.getOutstandingFees(this.student_id)
      .subscribe(
        (results: any) => {
          var data = results;

          this.feesModel.note = data.note;
          this.outstanding = data.outstanding;
          this.displayVal = this.outstanding;
          if (this.outstanding == '' || this.outstanding === undefined) {
            this.tempOutstanding = this.finalTotal;
            this.displayVal = this.finalTotal;
          } else {
            this.tempOutstanding = this.outstanding;
          }
        });

  }

  imageFileBinary: any;
  reloadPage: boolean = false;
  outstanding: any;
  tempOutstanding: any;

  viewImage(student_id: any) {

    this.studentService.showStudentPhoto(this.student_id)
      .subscribe(
        (results: any) => {
          // alert(JSON.stringify(results.image));
          this.retrieveResonse = results;
          this.base64Data = this.retrieveResonse.image;
          this.retrievedImage = 'data:image/jpeg;base64,' + this.base64Data;
        });





    //  this.ngOnInit();

    // this.ngOnInit();
    //start get image code
    //   alert(student_id)
    // this.http.get('http://192.168.1.38:9095/api/student/get/images/'+student_id)
    //       .subscribe(
    //         (  res: any) => {
    //           alert(JSON.stringify(res));

    //           this.retrieveResonse =res ;
    //           this.base64Data = this.retrieveResonse.image;
    //           this.retrievedImage = 'data:image/jpeg;base64,' +this.base64Data;
    //           alert(this.retrievedImage)
    //         }
    //       );
    //end get image code
  }


  feesModel: Fees = {
    class_name: '',
    childKit: '',
    admissionForm: '',
    admissionFees: '',
    tuitionFees: '',
    tuitionFeesApril: '',
    tuitionFeesJune: '',
    tuitionFeesNovember: '',
    busfees: '',
    busFeesApril: '',
    busFeesJune: '',
    busFeesNovember: '',
    child_id: '',
    admision_for_session: '',
    paid: '',
    outstand: '',
    student_fees: '',
    pramoted: '',
    note: '',
    tution_fees_paid: '',
    bus_fees_paid: '',
    paidFeespaid: '',
    admissionFormPaid: '',
    admissionFeesPaid: ''
  }



  setFeesData(className: string, place_name: string) {
    if (className == 'Play Group') {
      this.feesModel.class_name = className;
      this.feesModel.childKit = "4500";
      this.feesModel.admissionForm = "500";
      this.feesModel.admissionFees = "1000";
      this.feesModel.tuitionFees = "13000";
      this.feesModel.tuitionFeesApril = "4000";
      this.feesModel.tuitionFeesJune = "4500";
      this.feesModel.tuitionFeesNovember = "4500";
      this.finalTotal = 4500;
      this.finalTotal = this.finalTotal + 500;
      this.finalTotal = this.finalTotal + 1000;
      this.finalTotal = this.finalTotal + 13000;

    } else if (className == 'Nursery') {
      this.feesModel.class_name = className;
      this.feesModel.childKit = "7208";
      this.feesModel.admissionForm = "500";
      this.feesModel.admissionFees = "1000";
      this.feesModel.tuitionFees = "20000";
      this.feesModel.tuitionFeesApril = "6000";
      this.feesModel.tuitionFeesJune = "7000";
      this.feesModel.tuitionFeesNovember = "7000";
      this.finalTotal = 7208;
      this.finalTotal = this.finalTotal + 500;
      this.finalTotal = this.finalTotal + 1000;
      this.finalTotal = this.finalTotal + 20000;

    } else if (className == 'Jr.KG') {
      this.feesModel.class_name = className;
      this.feesModel.childKit = "7745";
      this.feesModel.admissionForm = "500";
      this.feesModel.admissionFees = "2000";
      this.feesModel.tuitionFees = "21000";
      this.feesModel.tuitionFeesApril = "7000";
      this.feesModel.tuitionFeesJune = "7000";
      this.feesModel.tuitionFeesNovember = "7000";
      this.finalTotal = 7745;
      this.finalTotal = this.finalTotal + 500;
      this.finalTotal = this.finalTotal + 2000;
      this.finalTotal = this.finalTotal + 21000;



    } else if (className == 'Sr.KG') {
      this.feesModel.class_name = className;
      this.feesModel.childKit = "8176";
      this.feesModel.admissionForm = "500";
      this.feesModel.admissionFees = "2000";
      this.feesModel.tuitionFees = "22000";
      this.feesModel.tuitionFeesApril = "7000";
      this.feesModel.tuitionFeesJune = "7500";
      this.feesModel.tuitionFeesNovember = "7500";
      this.finalTotal = 8176;
      this.finalTotal = this.finalTotal + 500;
      this.finalTotal = this.finalTotal + 2000;
      this.finalTotal = this.finalTotal + 22000;




    }

    // ----------------------------bus details------------//

    if (this.place_name == 'Sendhwa') {
      this.feesModel.busfees = "9900";
      this.feesModel.busFeesApril = "3300";
      this.feesModel.busFeesJune = "3300";
      this.feesModel.busFeesNovember = "3300";

      this.finalTotal = this.finalTotal + 9900;
    }
    else if (this.place_name == 'Niwali') {
      this.feesModel.busfees = "17600";
      this.feesModel.busFeesApril = "5600";
      this.feesModel.busFeesJune = "6000";
      this.feesModel.busFeesNovember = "6000";
      this.finalTotal = this.finalTotal + 17600;
    }
    else if (this.place_name == 'Chatli') {
      this.feesModel.busfees = "13200";
      this.feesModel.busFeesApril = "4000";
      this.feesModel.busFeesJune = "4600";
      this.feesModel.busFeesNovember = "4600";
      this.finalTotal = this.finalTotal + 13200;


    }
    else if (this.place_name == 'Jogwada') {
      this.feesModel.busfees = "13200";
      this.feesModel.busFeesApril = "4000";
      this.feesModel.busFeesJune = "4600";
      this.feesModel.busFeesNovember = "4600";
      this.finalTotal = this.finalTotal + 13200;

    }
    else if (this.place_name == 'Dhanora') {
      this.feesModel.busfees = "18700";
      this.feesModel.busFeesApril = "6000";
      this.feesModel.busFeesJune = "6300";
      this.feesModel.busFeesNovember = "6400";
      this.finalTotal = this.finalTotal + 18700;


    }
    else if (this.place_name == 'Chachriya') {
      this.feesModel.busfees = "19800";
      this.feesModel.busFeesApril = "6600";
      this.feesModel.busFeesJune = "6600";
      this.feesModel.busFeesNovember = "6600";
      this.finalTotal = this.finalTotal + 19800;

    }
    else if (this.place_name == 'Ozar') {
      this.feesModel.busfees = "16500";
      this.feesModel.busFeesApril = "5500";
      this.feesModel.busFeesJune = "5500";
      this.feesModel.busFeesNovember = "5500";
      this.finalTotal = this.finalTotal + 16500;

    }
    else if (this.place_name == 'Nagalwadi') {
      this.feesModel.busfees = "17600";
      this.feesModel.busFeesApril = "5600";
      this.feesModel.busFeesJune = "6000";
      this.feesModel.busFeesNovember = "6000";
      this.finalTotal = this.finalTotal + 17600;

    }

  }
  if() {
    this.Outstand = this.Outstand;
    this.Outstand = this.Outstand - this.finalTotal;

  }


  studentfees() {
    this.router.navigate(['Registration'])
  }
  home() {
    this.router.navigate([''])
  }


  studentdata() {
    this.router.navigate(['studentdata'])
  }
  url = "assets/img/m-final.jpeg";

  bus_status: any = ''

  saveStudentFees() {

    const data = {
      student_id: this.student_id,
      bus_status: this.bus_status,
      total_fees: this.finalTotal,
      paid: this.feesModel.paid,
      outstand: this.displayVal,
      student_fees: this.finalTotal,
      child_kit_fees: this.feesModel.childKit,
      admission_form_fees: this.feesModel.admissionForm,
      admission_fees: this.feesModel.admissionFees,
      tution_fees: this.feesModel.tuitionFees,
      tution_april_fees: this.feesModel.tuitionFeesApril,
      tution_june_fees: this.feesModel.tuitionFeesJune,
      tution_november_fees: this.feesModel.tuitionFeesNovember,
      bus_fees: this.feesModel.busfees,
      bus_april_fees: this.feesModel.busFeesApril,
      bus_june_fees: this.feesModel.busFeesJune,
      bus_november_fees: this.feesModel.busFeesNovember,
      note: this.feesModel.note,
      bus_fees_paid: this.feesModel.bus_fees_paid,
      tution_fees_paid: this.feesModel.tution_fees_paid,
      admission_form_paid: this.feesModel.admissionFormPaid,
      admission_fees_paid: this.feesModel.admissionFeesPaid
    }
    this.spinner.show();
    this.studentService.updateStudentFees(data, this.student_id)
      .subscribe(
        (results: any) => {
          this.spinner.hide();

          // alert(results.message)
        },
        (error: any) => {
          console.log(error);
        });
  }

  onselectFile(e: any) {
    if (e.target.files) {
      var reader = new FileReader();
      reader.readAsDataURL(e.target.files[0]);
      reader.onload = (event: any) => {
        this.url = event.target.result;
      }
    }


  }


  displayVal: any;
  getAdmissionFormValue(val: string) {
    if (this.tempOutstanding == '') {
      this.tempOutstanding = this.finalTotal;
    }

    if (this.feesModel.bus_fees_paid == '') {
      this.feesModel.bus_fees_paid = "0";
    }
    if (this.feesModel.tution_fees_paid == '') {
      this.feesModel.tution_fees_paid = "0";
    } 
    if (this.feesModel.paid == '') {
      this.feesModel.paid = "0";
    } 
    if (this.feesModel.admissionFeesPaid == '') {
      this.feesModel.admissionFeesPaid = "0";
    } 
    
    if (val == '') {
      val = "0";    
    }
    // alert(this.tempOutstanding)
    this.displayVal = parseInt(this.tempOutstanding) - (parseInt(val) + parseInt(this.feesModel.bus_fees_paid) + parseInt(this.feesModel.tution_fees_paid) + parseInt(this.feesModel.paid) +  parseInt(this.feesModel.admissionFeesPaid) );
    if (this.displayVal == '' || this.displayVal == null) {
      this.displayVal = 0
    }

  }
  getAdmissionFeesValue(val: string) {
    if (this.tempOutstanding == '') {
      this.tempOutstanding = this.finalTotal;
    }

    if (this.feesModel.bus_fees_paid == '') {
      this.feesModel.bus_fees_paid = "0";
    }
    if (this.feesModel.tution_fees_paid == '') {
      this.feesModel.tution_fees_paid = "0";
    } 
    if (this.feesModel.admissionFormPaid == '') {
      this.feesModel.admissionFormPaid = "0";
    } 
    if (this.feesModel.paid == '') {
      this.feesModel.paid = "0";
    } 
    
    if (val == '') {
      val = "0";    
    }
    // alert(this.tempOutstanding)
    this.displayVal = parseInt(this.tempOutstanding) - (parseInt(val) + parseInt(this.feesModel.bus_fees_paid) + parseInt(this.feesModel.tution_fees_paid) + parseInt(this.feesModel.admissionFormPaid) +  parseInt(this.feesModel.paid) );
    if (this.displayVal == '' || this.displayVal == null) {
      this.displayVal = 0
    }

  }


  getValue(val: string) {

    if (this.tempOutstanding == '') {
      this.tempOutstanding = this.finalTotal;
    }

    if (this.feesModel.bus_fees_paid == '') {
      this.feesModel.bus_fees_paid = "0";
    }
    if (this.feesModel.tution_fees_paid == '') {
      this.feesModel.tution_fees_paid = "0";
    } 
    if (this.feesModel.admissionFormPaid == '') {
      this.feesModel.admissionFormPaid = "0";
    } 
    if (this.feesModel.admissionFeesPaid == '') {
      this.feesModel.admissionFeesPaid = "0";
    } 
    
    if (val == '') {
      val = "0";    
    }
    // alert(this.tempOutstanding)
    this.displayVal = parseInt(this.tempOutstanding) - (parseInt(val) + parseInt(this.feesModel.bus_fees_paid) + parseInt(this.feesModel.tution_fees_paid) + parseInt(this.feesModel.admissionFormPaid) +  parseInt(this.feesModel.admissionFeesPaid) );
    if (this.displayVal == '' || this.displayVal == null) {
      this.displayVal = 0
    }
  }


  getValueTution(val: string) {
    // alert(this.feesModel.tution_fees_paid)
    // alert(this.finalTotal)
    if (this.tempOutstanding == '') {
      this.tempOutstanding = this.finalTotal;
    }
    if (this.feesModel.bus_fees_paid == '') {
      this.feesModel.bus_fees_paid = "0";
    }
    if (this.feesModel.paid == '') {
      this.feesModel.paid = "0";
    } 
    if (this.feesModel.admissionFormPaid == '') {
      this.feesModel.admissionFormPaid = "0";
    } 
    if (this.feesModel.admissionFeesPaid == '') {
      this.feesModel.admissionFeesPaid = "0";
    } 
    
    if (val == '') {
      val = "0";
    }
    this.displayVal = parseInt(this.tempOutstanding) - (parseInt(this.feesModel.bus_fees_paid) + parseInt(this.feesModel.paid) + parseInt(val)+     parseInt(this.feesModel.admissionFormPaid) +  parseInt(this.feesModel.admissionFeesPaid));
    //  + parseInt(this.feesModel.paid)+parseInt(val)))
    if (this.displayVal == '' || this.displayVal == null) {
      this.displayVal = 0
    }
  }

  getValueBus(val: string) {

    if (this.tempOutstanding == '') {
      this.tempOutstanding = this.finalTotal;
    }
    if (this.feesModel.tution_fees_paid == '') {
      this.feesModel.tution_fees_paid = "0";
    }
    if (this.feesModel.paid == '') {
      this.feesModel.paid = "0";
    }
    if (this.feesModel.admissionFormPaid == '') {
      this.feesModel.admissionFormPaid = "0";
    } 
    if (this.feesModel.admissionFeesPaid == '') {
      this.feesModel.admissionFeesPaid = "0";
    } 
    


    if (val == '') {
      val = "0";
    }

    this.displayVal = parseInt(this.tempOutstanding) - (parseInt(val) + parseInt(this.feesModel.paid) + parseInt(this.feesModel.tution_fees_paid)+ parseInt(this.feesModel.admissionFormPaid) +  parseInt(this.feesModel.admissionFeesPaid)
    );

    if (this.displayVal == '' || this.displayVal == null) {
      this.displayVal = 0
    }

  }


  nextClass: any = "";

  promoted() {

    if (this.className == "Play Group") {
      this.nextClass = "Nursery";
    }
    if (this.className == "Nursery") {
      this.nextClass = "Jr.KG";
    }
    if (this.className == "Jr.KG") {
      this.nextClass = "Sr.KG";
    }

    const data = {
      student_id: this.student_id,
      pramoted: this.feesModel.pramoted,
      year: this.year,
      class_name: this.className
    }


    this.spinner.show();
    // this.setFeesData(this.nextClass,this.place_name); 
    this.studentService.updatePromotedStudent(data, this.student_id)
      .subscribe(
        (results: any) => {
          //  alert(results.Student_ID)
          this.spinner.hide();
          this.router.navigate(['Registration/' + results.Student_ID], {
            queryParams: { data: btoa(JSON.stringify(data)) }
          })
        },
        (error: any) => {
          console.log(error);
        });
  }

  isEditableShown: any = true; // hidden by default

  toogleEditTag() {
    this.isEditableShown = false;
  }

  tempAmount: any;
  amnt: any;

  changeTotal(e: any, value: any) {
    // alert("kit value- "+ this.feesModel.childKit);
    // alert("change value  -"+ e.target.value);
    // kit value

    if (e.target.value == '') {
      e.target.value = 0;
    }

    if (value == 'childkit') {
      if (parseInt(this.feesModel.childKit) > parseInt(e.target.value)) {
        this.tempAmount = parseInt(this.feesModel.childKit) - parseInt(e.target.value);
        this.finalTotal = parseInt(this.finalTotal) - parseInt(this.tempAmount);
        this.feesModel.childKit = e.target.value;
      } else {
        this.tempAmount = parseInt(e.target.value) - parseInt(this.feesModel.childKit);
        this.finalTotal = parseInt(this.finalTotal) + parseInt(this.tempAmount);
        this.feesModel.childKit = e.target.value;
      }
    }


    // admission form
    if (value == 'admissionform') {
      if (parseInt(this.feesModel.admissionForm) > parseInt(e.target.value)) {
        this.tempAmount = parseInt(this.feesModel.admissionForm) - parseInt(e.target.value);
        this.finalTotal = parseInt(this.finalTotal) - parseInt(this.tempAmount);
        this.feesModel.admissionForm = e.target.value;
      } else {
        this.tempAmount = parseInt(e.target.value) - parseInt(this.feesModel.admissionForm);
        this.finalTotal = parseInt(this.finalTotal) + parseInt(this.tempAmount);
        this.feesModel.admissionForm = e.target.value;
      }
    }

    //admissionFees
    if (value == 'admissionFees') {
      if (parseInt(this.feesModel.admissionFees) > parseInt(e.target.value)) {
        this.tempAmount = parseInt(this.feesModel.admissionFees) - parseInt(e.target.value);
        this.finalTotal = parseInt(this.finalTotal) - parseInt(this.tempAmount);
        this.feesModel.admissionFees = e.target.value;
      } else {
        this.tempAmount = parseInt(e.target.value) - parseInt(this.feesModel.admissionFees);
        this.finalTotal = parseInt(this.finalTotal) + parseInt(this.tempAmount);
        this.feesModel.admissionFees = e.target.value;
      }
    }

    //admissionFees
    if (value == 'tuitionFees') {
      if (parseInt(this.feesModel.tuitionFees) > parseInt(e.target.value)) {
        this.tempAmount = parseInt(this.feesModel.tuitionFees) - parseInt(e.target.value);
        this.finalTotal = parseInt(this.finalTotal) - parseInt(this.tempAmount);
        this.feesModel.tuitionFees = e.target.value;
      } else {
        this.tempAmount = parseInt(e.target.value) - parseInt(this.feesModel.tuitionFees);
        this.finalTotal = parseInt(this.finalTotal) + parseInt(this.tempAmount);
        this.feesModel.tuitionFees = e.target.value;
      }

      this.amnt = parseInt(this.feesModel.tuitionFees) / 3;
      this.feesModel.tuitionFeesApril = Math.floor(this.amnt) + "";
      this.feesModel.tuitionFeesJune = Math.floor(this.amnt) + "";
      this.feesModel.tuitionFeesNovember = Math.floor(this.amnt) + "";
    }

    //admissionFees
    if (value == 'busfees') {
      if (parseInt(this.feesModel.busfees) > parseInt(e.target.value)) {
        this.tempAmount = parseInt(this.feesModel.busfees) - parseInt(e.target.value);
        this.finalTotal = parseInt(this.finalTotal) - parseInt(this.tempAmount);
        this.feesModel.busfees = e.target.value;
      } else {
        this.tempAmount = parseInt(e.target.value) - parseInt(this.feesModel.busfees);
        this.finalTotal = parseInt(this.finalTotal) + parseInt(this.tempAmount);
        this.feesModel.busfees = e.target.value;
      }

      this.amnt = parseInt(this.feesModel.busfees) / 3;
      this.feesModel.busFeesApril = Math.floor(this.amnt) + "";
      this.feesModel.busFeesJune = Math.floor(this.amnt) + "";
      this.feesModel.busFeesNovember = Math.floor(this.amnt) + "";
    }





  }
  //   paidFeespaid:any;

  //   paidAllfees()
  //   {
  //  this.paidFeespaid = (parseInt(this.feesModel.bus_fees_paid) + parseInt(this.feesModel.paid) + parseInt(this.feesModel.tution_fees_paid));
  //     alert(this.paidFeespaid)
  //   }

}



