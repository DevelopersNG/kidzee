import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { FilterModel } from 'src/app/model/filter-model';
import { Registration } from 'src/app/model/registration.model';
import { studentShow } from 'src/app/model/student-show';
import { StudentService } from 'src/app/service/student.service';

@Component({
  selector: 'app-studentdata',
  templateUrl: './studentdata.component.html',
  styleUrls: ['./studentdata.component.css']
})
export class StudentdataComponent implements OnInit {

  constructor(private router:Router, private studentService: StudentService,private spinner: NgxSpinnerService) { }

  ngOnInit(): void {
    this.getAllStudentData();

  }


  filter: FilterModel={
    childId: '',
    className: '',
    year: '',
    searchFrom: '',
    searchTo: ''
  }


  allStudentDetails:any;


  totalRecords: number=0
  page:number=1
  otherDetails:any
  busDetails:any
  tutionDetails:any
  
  final_paid:any;
  final_fees:any;
  final_outstand_fees:any;

  getAllStudentData() {

    // const data={
    //   child_id: this.filter.childId,
    //   class_name: this.filter.className,
    //   year: this.filter.year
    // }




    const data={
      child_id:this.filter.childId,
      class_name: this.filter.className,
      year: this.filter.year,
      search_form_date: this.filter.searchFrom,
      search_to_date: this.filter.searchTo,
    }
    this.studentService.getAllStudentData(data)
        .subscribe(
          (results: any) => {
       
            // alert(JSON.stringify(results[0].data));
            this.allStudentDetails=results;
            this.otherDetails=results[0].data;
            this.busDetails=results[0].bus;
            this.tutionDetails=results[0].tution;
            this.final_paid=results[results.length-1].final_total_paid;
            this.final_fees=results[results.length-1].final_fees;
            this.final_outstand_fees=results[results.length-1].final_outstand_fees;
            this.totalRecords=  this.allStudentDetails.length;
              if(this.totalRecords<10){
                this.page=1;
              }
            // alert(this.allStudentDetails)
          },
          (error: any) => {
            console.log(error);
          });
  }
  
  retrievedImage: any;
  base64Data: any;
  retrieveResonse: any;
 
  
  imageFileBinary:any;
  reloadPage:boolean=false;

   viewImage(student_id: any) {

    this.studentService.showStudentPhoto(this.student_id)
    .subscribe(
      (results: any) => {
        // alert(JSON.stringify(results.image));
        this.retrieveResonse =results ;
        this.base64Data = this.retrieveResonse.image;
        this.retrievedImage = 'data:image/jpeg;base64,' +this.base64Data ;
      });
    }
  

show: studentShow={
  className: '',
  place_name: '',
  childId: '',
  aadharNO: '',
  Admission: '',
  bank_name: '',
  ac_no: '',
  ifsc_code: '',
  fullNameofstudent: '',
  Sex: '',
  Male: '',
  dateOfbirth: '',
  Age: '',
  placeof: '',
  Nationality: '',
  MotherTongue: '',
  sche_cast: '',
  Religion: '',
  cast: '',
  FatherName: '',
  motherName: '',
  PostalAddress: '',
  mobilNo: '',
  WhatsAppno: '',
  emailAddress: '',
  guardianName: '',
  Relationship: '',
  PostalAddressfamily: '',
  bus_status: '',
  bus_place: '',
  year: '',
  total_fees: '',
  paid: '',
  outstand: '',
  note: '',
  student_fees: '',
  child_kit_fees: '',
  admission_form_fees: '',
  admission_fees: '',
  tution_fees: '',
  tution_april_fees: '',
  tution_june_fees: '',
  tution_november_fees: '',
  bus_fees: '',
  bus_april_fees: '',
  bus_june_fees: '',
  bus_november_fees: '',
  sssm_id: '',
  bus_number: '',
  bus_fees_paid: '',
  paidTutionfee: '',
  paidFeespaid: '',
  admission_fees_paid: '',
  admission_form_paid: ''
};

student_id:any;

setOtherStudentData(data:any){
  this.spinner.show();
   this.show.childId=data.child_id;
   
    this.student_id=data.student_id;
    this.show.className=data.class_name
    this.show.place_name=data.place_name
    this.show.aadharNO=data.aadhar_number
    this.show.Age=data.age
   
    this.show.Admission=data.admission_fees
    this.show.bank_name=data.bank_name
    this.show.ac_no=data.ac_no
    
    this.show.ifsc_code=data.ifsc_code
    this.show.fullNameofstudent=data.name
    this.show.Sex=data.gender
    // this.show.Male=data.
    this.show.dateOfbirth=data.dob
   
    this.show.placeof=data.place_of_birth
    this.show.Nationality=data.nationnality
    this.show.MotherTongue=data.mother_tonge
    this.show.sche_cast=data.sche_cast
    this.show.Religion=data.religion
    this.show.cast=data.cast
    this.show.FatherName=data.father_name
    this.show.motherName=data.mother_name
    this.show.PostalAddress=data.postal_address
    this.show.mobilNo=data.mobile_number
    this.show.WhatsAppno=data.whatapp_number
    this.show.emailAddress=data.email_id
    this.show.guardianName=data.guardian_name
    this.show.Relationship=data.relationship
    this.show.PostalAddressfamily=data.first_postal_address
    this.show.bus_status=data.bus_status
    this.show.bus_place=data.place_name
    this.show.year=data.year
    this.show.total_fees=data.total_fees
    this.show.paid=data.paid
    this.show.outstand=data.outstand
    this.show.note=data.note
    this.show.student_fees=data.student_fees
    this.show.total_fees=data.total_fees
    this.show.child_kit_fees=data.child_kit_fees
    this.show.admission_form_fees=data.admission_form_fees
    this.show.note=data.note
    this.show.admission_fees=data.admission_fees
    this.show.tution_fees=data.tution_fees
    this.show.tution_april_fees=data.tution_april_fees
    this.show.tution_june_fees=data.tution_june_fees
    this.show.tution_november_fees=data.tution_november_fees
    this.show.bus_fees=data.bus_fees
    this.show.bus_april_fees=data.bus_april_fees
    this.show.bus_june_fees=data.bus_june_fees
    this.show.bus_november_fees=data.bus_november_fees

    this.show.bus_number=data.bus_number
    this.show.sssm_id=data.sssm_id
    this.show.bus_fees_paid=data.bus_fees_paid
    this.show.paidTutionfee=data.tution_fees_paid
    this.show.admission_form_paid=data.admission_form_paid
    this.show.admission_fees_paid=data.admission_fees_paid

    this.viewImage(this.student_id);
    this.spinner.hide();
  
  }
  home(){
    this.router.navigate([''])
  }


  callRegistration()
  {
    // alert(this.student_id)
    this.router.navigate(['Registration/'+this.student_id])
  }



  DeleteData(student_id:any,fees_id:any){
    if(confirm("Delete this student detail? "))
    {

      const data={
        student_id:student_id,
        id:fees_id
        }
        this.studentService.deleteData(student_id, fees_id,data)
        
        .subscribe(
          (results: any) => {
         
          });
          location.reload();
          
    }
    

   
     
  }
    
  
  

  
  


 
}
