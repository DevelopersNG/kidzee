import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Registration } from 'src/app/model/registration.model';
import { FormGroup, RequiredValidator } from '@angular/forms';
import { FormControl } from '@angular/forms';
import { Validators } from '@angular/forms';
import { StudentService } from 'src/app/service/student.service';
import { HttpClient, HttpHeaders, HttpEventType } from '@angular/common/http';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})

export class RegistrationComponent implements OnInit {

  constructor(private router: Router,
    private route: ActivatedRoute,
    private studentService: StudentService,
    private http: HttpClient,
    private spinner: NgxSpinnerService) {

    this.form = new FormGroup(
      {
        child_id: new FormControl('',),
        aadhar_number: new FormControl(''),
        year: new FormControl(''),
        bank_name: new FormControl(''),
        ac_no: new FormControl(''),
        ifsc_code: new FormControl(''),
        name: new FormControl(''),
        gender: new FormControl(''),
        Male: new FormControl(''),
        dob: new FormControl(''),
        age: new FormControl(''),
        place_of_birth: new FormControl(''),
        nationnality: new FormControl(''),
        mother_tonge: new FormControl(''),
        sche_cast: new FormControl(''),
        religion: new FormControl(''),
        cast: new FormControl(''),
        father_name: new FormControl(''),
        mother_name: new FormControl(''),
        postal_address: new FormControl(''),
        mobile_number: new FormControl(''),
        whatapp_number: new FormControl(''),
        email_id: new FormControl(''),
        guardian_name: new FormControl(''),
        relationship: new FormControl(''),
        PostalAddressfamily: new FormControl(''),
        first_postal_address: new FormControl(''),
        busStop: new FormControl(''),
        class_name: new FormControl(''),
        place_name: new FormControl(''),
        bus_status: new FormControl(''),
        bus_place: new FormControl(''),
        bus_number: new FormControl(''),
        sssm_id: new FormControl(''),
      }
    )
  }




  className: any;
  form: any;

  student_id: any;
  ngOnInit(): void {
    this.route.queryParams.subscribe((params => {
      this.student_id = this.route.snapshot.paramMap.get('id');
      // alert(this.student_id)

      if (this.student_id != null && this.student_id != '') {
        this.setStudentDetails(this.student_id);
      }
      this.viewImage(this.student_id);
    }))
  }

  urls: any;

  viewImage(student_id: any) {
    this.studentService.showStudentPhoto(this.student_id)
      .subscribe(
        (results: any) => {
          // alert(JSON.stringify(results.image));
          this.retrieveResonse = results;
          this.base64Data = this.retrieveResonse.image;
          this.urls = 'data:image/jpeg;base64,' + this.base64Data;
          // alert(this.retrievedImage)
        });
        // this.ngOnInit();

    //start get image code
    //   alert(student_id)
    // this.http.get('http://192.168.1.38:9095/api/student/get/images/'+student_id)
    //       .subscribe(
    //         (  res: any) => {
    //           alert(JSON.stringify(res));

    //           this.retrieveResonse =res ;
    //           this.base64Data = this.retrieveResonse.image;
    //           this.retrievedImage = 'data:image/jpeg;base64,' +this.base64Data;
    //           alert(this.retrievedImage)
    //         }
    //       );
    //end get image code
  }




  studentDetails: any;

  setStudentDetails(student_id: any) {
    this.studentService.getStudent(student_id)
      .subscribe(
        (results: any) => {
          this.regst.childId = results.child_id;
          this.regst.aadharNO = results.aadhar_number;
          this.regst.year = results.year;
          this.regst.className = results.class_name;
          this.regst.fullNameofstudent = results.name;
          this.regst.Sex = results.gender;
          this.regst.dateOfbirth = results.dob;
          this.regst.Age = results.age;
          this.regst.placeof = results.place_of_birth;
          this.regst.Nationality = results.nationnality;
          this.regst.MotherTongue = results.mother_tonge;
          this.regst.sche_cast = results.sche_cast;
          this.regst.Religion = results.religion;
          this.regst.cast = results.cast;
          this.regst.FatherName = results.father_name;
          this.regst.motherName = results.mother_name;
          this.regst.PostalAddress = results.postal_address;
          this.regst.mobilNo = results.mobile_number;
          this.regst.WhatsAppno = results.whatapp_number;
          this.regst.emailAddress = results.email_id;
          this.regst.guardianName = results.guardian_name;
          this.regst.Relationship = results.relationship;
          this.regst.PostalAddress = results.postal_address;
          this.regst.PostalAddressfamily = results.first_postal_address;
          this.regst.bank_name = results.bank_name;
          this.regst.ifsc_code = results.ifsc_code;
          this.regst.ac_no = results.ac_no;
          this.regst.cast = results.cast;
          this.regst.bus_status = results.bus_status;
          this.regst.place_name = results.place_name;
          this.regst.busNumber = results.bus_Number;
          this.regst.sssm_id = results.sssm_id;

          if (results.place_name != "") {
            this.showMe = true;
          }        
          
          // this.spinner.hide();

          // this.regst.busService=results.first_postal_address;

          // alert(JSON.stringify(results))
        },
        (error: any) => {
          // this.spinner.hide();
          console.log(error);
        });
  }

  studentfees() {
    const data = {
      className: this.regst.className,
      place_name: this.regst.place_name,
      child_id: this.regst.childId,
      aadhar_number: this.regst.aadharNO,
      year: this.regst.year,
      bank_name: this.regst.bank_name,
      ac_no: this.regst.ac_no,
      ifsc_code: this.regst.ifsc_code,
      name: this.regst.fullNameofstudent,
      gender: this.regst.Sex,
      Male: this.regst.Male,
      dob: this.regst.dateOfbirth,
      age: this.regst.Age,
      placeof: this.regst.placeof,
      nationnality: this.regst.Nationality,
      mother_tonge: this.regst.MotherTongue,
      sche_cast: this.regst.sche_cast,
      religion: this.regst.Religion,
      cast: this.regst.cast,
      father_name: this.regst.FatherName,
      mother_name: this.regst.motherName,
      postal_address: this.regst.PostalAddress,
      mobel_number: this.regst.mobilNo,
      whatapp_number: this.regst.WhatsAppno,
      email_id: this.regst.emailAddress,
      guardian_name: this.regst.guardianName,
      relationship: this.regst.Relationship,
      PostalAddressfamily: this.regst.PostalAddressfamily,
      first_postal_address: this.regst.PostalAddress,

    }
    // alert(this.regst.childId)
    this.router.navigate(['student/fees/' + this.regst.className + '/' + this.regst.place_name])
  }


  regst: Registration = {
    className: '',
    place_name: '',
    childId: '',
    aadharNO: '',
    Admission: '',
    bank_name: '',
    ac_no: '',
    ifsc_code: '',
    fullNameofstudent: '',
    Sex: '',
    Male: '',
    dateOfbirth: '',
    Age: '',
    placeof: '',
    Nationality: '',
    MotherTongue: '',
    sche_cast: '',
    Religion: '',
    cast: '',
    FatherName: '',
    motherName: '',
    PostalAddress: '',
    mobilNo: '',
    WhatsAppno: '',
    emailAddress: '',
    guardianName: '',
    Relationship: '',
    PostalAddressfamily: '',
    bus_place: '',
    bus_status: '',
    year: '',
    sssm_id: '',
    file: '',
    busNumber: '',
    bus_number: ''
  }
  registrationDetail: any


  type: any;


  selectedFile!: File;
  retrievedImage: any;
  base64Data: any;
  retrieveResonse: any;
  // message: string;
  imageName: any;
  url!: File;
  clickButton: boolean = false;




  onselectFile(e: any) {
    this.selectedFile = e.target.files[0];
    //  alert(e.target.files[0])
    if (e.target.files) {
      var reader = new FileReader();
      reader.readAsDataURL(e.target.files[0]);
      reader.onload = (event: any) => {
        this.url = event.target.result;
        this.clickButton = true;
      }
    }
  }




  // saveCall() {
  //   let data: any = this.form.value;
  //   // alert(JSON.stringify(data))

  //   // this.router.navigate(['student/fees/'], {
  //   //   queryParams: { data: btoa(JSON.stringify(data)) }
  //   // })
  //   this.studentService.updateStudent(data)
  //     .subscribe(
  //       (results: any) => {
  //         alert(results.message)
  //         this.router.navigate(['student/fees/'+results.message], {
  //           queryParams: { data: btoa(JSON.stringify(data)) }
  //         })
  //       },
  //       (error: any) => {
  //         console.log(error);
  //       });
  // }


  loginForm = new FormGroup({

    name: new FormControl('', [Validators.required, Validators.pattern('[a-zA-z]+$')]),
    email: new FormControl('', [Validators.required, Validators.email]),
  })

  get name() {
    return this.loginForm.get('name')
  }

  showMe: boolean = false

  toogleTag() {
    this.showMe = !this.showMe
  }


  erroBirthday: any = "";
  CalculateAge() {
    if (this.regst.dateOfbirth) {
      const myDate = new Date(this.regst.dateOfbirth);
      var today = new Date();
      if (myDate > today) {
        this.erroBirthday = " Invalid birth date";
        this.regst.Age = "";
      } else {
        this.erroBirthday = "";
        const timeDiff = Math.abs(Date.now() - myDate.getTime());
        //Used Math.floor instead of Math.ceil
        //so 26 years and 140 days would be considered as 26, not 27.
        this.regst.Age = Math.floor((timeDiff / (1000 * 3600 * 24)) / 365) + " years";
      }

    }
  }




  phoneError: any
  x = 10;

  
  
  // validateNo(e: any) {
  //   if (e.target.value != '') {
  //     const charCode = e.which ? e.which : e.keyCode;
  //     // if (charCode > 31 && (charCode < 48 || charCode > 57) || charCode == 12) {
  //     if ((e.charCode >= 48 && e.charCode <= 57) || (e.charCode >= 96 && e.charCode <= 105) || e.charCode == 8) {
  //       this.phoneError = "Please enter valid mobile number";
  //     } else {
  //       if (e.target.value.length == 10) {
  //         this.phoneError = "";
  //       } else {
  //         this.phoneError = "Please Enter valid mobile number";
  //       }

  //     }
  //   } else {
  //     this.phoneError = "Please enter mobile number";
  //   }
    
  //   if(e.target.value==''){
  //     this.phoneError = "";
  //   }    
    
   
  // }

  checkErrorAdmission(e: any) {
    if (e.target.value != "") {
      this.AdmissionError = "";
    } else {
      this.AdmissionError = "Addmission Year should not be blank";
    }
  }

  checkErrorClass(e: any) {
    if (e.target.value != "") {
      this.ClassError = "";
    } else {
      this.ClassError = "Class Year should not be blank";
    }
  }


  checkErrordate(e: any) {
    if (e.target.value != "") {
      this.BirthdateError = "";
    } else {
      this.BirthdateError = "Date Year should not be blank";
    }
  }


  checkErrorGender(e: any) {

    if (e.target.value != "") {
      this.GenderError = "";
    } else {
      this.GenderError = "Gender should not be blank";
    }
  }


  checkErrorbusService(e: any) {
    if (e.target.value != "") {
      this.BusError = "";
    } else {
      this.BusError = " Bus Service should not be blank";
    }
  }



  checkErrorpostal(e: any) {
    if (e.target.value != "") {
      this.CurrentError = "";
    } else {
      this.CurrentError = "  Current Address should not be blank";
    }
  }

  checkErrorguardianName(e: any) {
    if (e.target.value != "") {
      this.GuardianError = "";
    } else {
      this.GuardianError = " Guardian should not be blank";
    }
  }

  checkErrorFatherName(e: any) {
    if (e.target.value != "") {
      this.FatherNameError = "";
    } else {
      this.FatherNameError = " Father name should not be blank";
    }
  }



  
  checkErrormotherNameError(e: any) {
    if (e.target.value != "") {
      this.motherNameError = "";
    } else {
      this.motherNameError = " Mother name should not be blank";
    }
  }








  aadharError: any
  y = 12;
  aadharNo(e: any) {
    if (e.target.value != '') {
           if (e.target.value.length == 12) {
          this.aadharError = "";
        }else{
          this.aadharError = "Enter your 12 digit aadhar number";
        } 
    }
  }

  




m = 10;
  validateNo(e: any) {
    if (e.target.value != '') {
           if (e.target.value.length == 10) {
          this.phoneError = "";
        }else{
          this.phoneError = "Enter your 10 digit  mobile number";
        } 
    }
  }

  home(){
    this.router.navigate([''])
  }

  Childid: any;

 


  checkFUllName(e: any) {

    this.fullNameofstudentError = "";
  }
  motherNameError:any;
  FatherNameError:any;
  AdmissionError: any;
  ClassError: any;
  GenderError: any;
  BirthdateError: any;
  CurrentError: any;
  GuardianError: any;
  postalError: any;
  BusError: any;
  fullNameofstudentError: any;
  checkCValidationForButton: boolean = false;

  saveCall() {

    let data: any = this.form.value;
    

    this.checkCValidationForButton = true;
    // alert(this.student_id)

    if (this.regst.childId == '') {
      this.Childid = "Child ID should not be blank";
      this.checkCValidationForButton = false;
    }

    if (this.regst.aadharNO == '') {
      this.aadharError = "Aadhar Number should not be blank";
      this.checkCValidationForButton = false;
    }


    
    if (this.regst.FatherName == '') {
      this.FatherNameError = "Father name should not be blank";
      this.checkCValidationForButton = false;
    }


    
    if (this.regst.motherName == '') {
      this.motherNameError = "Mother name should not be blank";
      this.checkCValidationForButton = false;
    }



    if (this.regst.year == '') {
      this.AdmissionError = "Addmission Year should not be blank";
      this.checkCValidationForButton = false;
    }

    if (this.regst.className == '') {
      this.ClassError = "Class should not blank";
      this.checkCValidationForButton = false;
    }

    if (this.regst.Sex == '') {
      this.GenderError = "Gender should not be blank";
      this.checkCValidationForButton = false;
    }

    if (this.regst.dateOfbirth == '') {
      this.BirthdateError = "Date of Birth should not be blank";
      this.checkCValidationForButton = false;
    }

    if (this.regst.mobilNo == '') {
      this.phoneError = "Phone Number should not be blank";
      this.checkCValidationForButton = false;
    }
    if (this.regst.PostalAddress == '') {
      this.CurrentError = "Date of Birth should not be blank";
      this.checkCValidationForButton = false;
    }
    if (this.regst.guardianName == '') {
      this.GuardianError = "Guardian should not be blank";
      this.checkCValidationForButton = false;
    }
    if (this.regst.PostalAddressfamily == '') {
      this.postalError = "Current Address should not be blank";
      this.checkCValidationForButton = false;
    }
    if (this.regst.bus_status == '') {
      this.BusError = "Bus Service should not be blank";
      this.checkCValidationForButton = false;
    }
    if (this.regst.fullNameofstudent == '') {
      this.fullNameofstudentError = "Student Name should not be blank";
      this.checkCValidationForButton = false;
    }

    if (this.selectedFile != null && this.selectedFile != undefined) {
      var myFormData = new FormData();
      myFormData.append('imageFile', this.selectedFile, this.selectedFile.name);
    }



    if (this.checkCValidationForButton) {
      this.spinner.show();
      if (this.student_id != '' && this.student_id != null) {
        this.studentService.updateExitingStudent(this.student_id, data)
          .subscribe(
            (results: any) => {
              var studentId = results.message;
              // save image in db 
              if (results.success == "yes") {

                if (this.selectedFile != null && this.selectedFile != undefined) {


                  this.studentService.uploadPhoto(results.message, myFormData)
                    .subscribe(
                      (results: any) => {
                      });

                }
                alert("Student Updated.....")
              } else {
                alert("Student Not Updated.....")
              }
              this.spinner.hide();
              this.router.navigate(['student/fees/' + results.message], {
                queryParams: { data: btoa(JSON.stringify(data)) }
              })
            },
            (error: any) => {
              this.spinner.hide();
              console.log(error);
            });

      } else {
        this.studentService.updateStudent(data)
          .subscribe(
            (results: any) => {

              if (results.success == "yes") {
                if (this.selectedFile != null && this.selectedFile != undefined) {

                  this.studentService.uploadPhoto(results.message, myFormData)
                    .subscribe(
                      (results: any) => {

                      });
                }
                alert("Student Updated.....");
              } else {
                alert("Student Not Updated.....");
              }

              this.spinner.hide();
              // start code image

              // this.http.post('http://192.168.1.38:9095/api/student/upload/images/' + results.message, myFormData, { observe: 'response' })
              //   .subscribe((response) => {

              //     // if (response.status === 200) {
              //     // this.message = 'Image uploaded successfully';

              //     //start get image code
              //     // this.http.get('http://192.168.1.38:9095/api/student/get/images/1')
              //     //       .subscribe(
              //     //         res => {
              //     //           this.retrieveResonse =res ;
              //       //           this.base64Data = this.retrieveResonse.image;
              //     //           this.retrievedImage = 'data:image/jpeg;base64,' +this.base64Data;
              //     //         }
              //     //       );
              //     //end get image code

              //     // } else {
              //     //   // this.message = 'Image not uploaded successfully';
              //     // }
              //   }
              //   );
              // image part done







              this.router.navigate(['student/fees/' + results.message], {
                queryParams: { data: btoa(JSON.stringify(data)) }
              })

            },
            (error: any) => {
              this.spinner.hide();
              console.log(error);
            });
      }
      //     }
    }
  }


}
