import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RegistrationComponent } from './component/registration/registration.component';
import { StudentdataComponent } from './component/studentdata/studentdata.component';
import { StudentfeeComponent } from './component/studentfee/studentfee.component';
import { HomeComponent } from './home/home.component';



const routes: Routes = [

{path:'',component:HomeComponent},
{path:'Registration',component:RegistrationComponent},
{path:'studentdata',component:StudentdataComponent},
{path:'student/fees',component:StudentfeeComponent},
{path:'student/fees/:id',component:StudentfeeComponent},
{path:'student/fees/:className/:placeName',component:StudentfeeComponent},
{path:'Registration/:id',component:RegistrationComponent},



];

@NgModule({
  imports: [RouterModule.forRoot(routes, {useHash:true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
