import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';


// for tomcat server
// const baseUrl = 'http://localhost:8080/api'


// for local server
const baseUrl = 'http://localhost:9095/api'

@Injectable({
  providedIn: 'root'
})

export class StudentService {
 
  constructor(private http: HttpClient) { }

  uploadPhoto(studentid: any, myFormData: FormData) {
    return this.http.post(baseUrl+"/student/upload/images/"+studentid,myFormData);
      }

 
  showStudentPhoto(student_id:any){
    return this.http.get(baseUrl+"/student/get/images/"+student_id);
  }

  updateStudent(data: any) {
    return this.http.post(baseUrl+"/student/insert",data);
  }

  updateExitingStudent(student_id:any,data: any) {
    return this.http.post(baseUrl+"/student/update/"+student_id,data);
  }

  updateStudentFees(data: any,student_id:any) {
    return this.http.post(baseUrl+"/student/fees/update/"+student_id,data);
  }
  
  updatePromotedStudent(data: any,student_id:any) {
    return this.http.post(baseUrl+"/student/pramoted/"+student_id,data);
  }

  getStudent(student_id:any){
    return this.http.get(baseUrl+"/student/get/"+student_id);
  }

  getAllStudentData(data: any){
    return this.http.post(baseUrl+"/student/get/filter",data);
  }

  uploadStudentPhotos(uploadImageData:any,student_id:any){
    return this.http.post(baseUrl+"/student/upload/images/"+student_id,uploadImageData);
  }

  deleteData(student_id:any,fees_id:any,data:any){
    return this.http.post(baseUrl+"/student/deleted/"+student_id+"/"+fees_id,data);
  }


  
  getOutstandingFees(student_id:any){
    return this.http.get(baseUrl+"/student/get/fees/outstanding/"+student_id);
  }

}
