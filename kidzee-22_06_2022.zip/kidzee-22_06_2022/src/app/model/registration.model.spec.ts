import { Registration } from './registration.model';

describe('Registration', () => {
  it('should create an instance', () => {
    expect(new Registration()).toBeTruthy();
  });
});
