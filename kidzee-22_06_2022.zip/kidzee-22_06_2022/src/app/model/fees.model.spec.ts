import { Fees } from './fees.model';

describe('Fees', () => {
  it('should create an instance', () => {
    expect(new Fees()).toBeTruthy();
  });
});
