export class FilterModel {
    childId:string='';
    className:string='';
    year:string=''
    searchFrom:string=''
    searchTo:string=''
}
